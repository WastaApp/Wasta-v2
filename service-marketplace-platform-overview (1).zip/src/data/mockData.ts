export const services = [
  {
    id: 'cleaning',
    name: 'Cleaning Services',
    icon: '🧹',
    color: 'from-blue-500 to-cyan-500',
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    border: 'border-blue-200',
    subcategories: [
      { id: 'deep-clean', name: 'Deep Cleaning', price: 150, duration: '3-4 hrs', icon: '🏠' },
      { id: 'move-in', name: 'Move In/Move Out', price: 250, duration: '4-6 hrs', icon: '📦' },
      { id: 'office', name: 'Office Cleaning', price: 180, duration: '2-3 hrs', icon: '🏢' },
      { id: 'window', name: 'Window Cleaning', price: 80, duration: '1-2 hrs', icon: '🪟' },
      { id: 'carpet', name: 'Carpet Cleaning', price: 120, duration: '2-3 hrs', icon: '🧼' },
    ],
  },
  {
    id: 'electrical',
    name: 'Electrical Services',
    icon: '⚡',
    color: 'from-amber-500 to-orange-500',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200',
    subcategories: [
      { id: 'wiring', name: 'House Wiring', price: 200, duration: '2-4 hrs', icon: '🔌' },
      { id: 'light-install', name: 'Light Installation', price: 75, duration: '1 hr', icon: '💡' },
      { id: 'panel', name: 'Panel Upgrade', price: 350, duration: '3-5 hrs', icon: '⚙️' },
      { id: 'emergency', name: 'Emergency Repair', price: 120, duration: '1 hr', icon: '🚨' },
    ],
  },
  {
    id: 'plumbing',
    name: 'Plumbing',
    icon: '🔧',
    color: 'from-emerald-500 to-teal-500',
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200',
    subcategories: [
      { id: 'leak', name: 'Leak Detection', price: 90, duration: '1 hr', icon: '💧' },
      { id: 'faucet', name: 'Faucet Repair', price: 60, duration: '30-60 min', icon: '🚰' },
      { id: 'drain', name: 'Drain Cleaning', price: 110, duration: '1-2 hrs', icon: '🌀' },
      { id: 'water-heater', name: 'Water Heater Service', price: 180, duration: '2-3 hrs', icon: '🌡️' },
    ],
  },
  {
    id: 'ac',
    name: 'AC Services',
    icon: '❄️',
    color: 'from-sky-500 to-blue-500',
    bg: 'bg-sky-50',
    text: 'text-sky-700',
    border: 'border-sky-200',
    subcategories: [
      { id: 'ac-install', name: 'AC Installation', price: 450, duration: '4-6 hrs', icon: '🔨' },
      { id: 'ac-repair', name: 'AC Repair', price: 120, duration: '1-2 hrs', icon: '🛠️' },
      { id: 'ac-service', name: 'AC Deep Service', price: 90, duration: '1.5 hrs', icon: '💨' },
      { id: 'duct', name: 'Duct Cleaning', price: 200, duration: '2-3 hrs', icon: '🌀' },
    ],
  },
  {
    id: 'beauty',
    name: 'Beauty & Salon',
    icon: '💅',
    color: 'from-pink-500 to-rose-500',
    bg: 'bg-pink-50',
    text: 'text-pink-700',
    border: 'border-pink-200',
    subcategories: [
      { id: 'haircut', name: 'Haircut & Style', price: 85, duration: '1 hr', icon: '💇' },
      { id: 'manicure', name: 'Manicure & Pedicure', price: 95, duration: '1.5 hrs', icon: '💅' },
      { id: 'facial', name: 'Premium Facial', price: 120, duration: '1 hr', icon: '✨' },
      { id: 'makeup', name: 'Bridal Makeup', price: 350, duration: '3 hrs', icon: '💄' },
    ],
  },
  {
    id: 'moving',
    name: 'Moving & Packing',
    icon: '🚚',
    color: 'from-violet-500 to-purple-500',
    bg: 'bg-violet-50',
    text: 'text-violet-700',
    border: 'border-violet-200',
    subcategories: [
      { id: 'local-move', name: 'Local Moving', price: 300, duration: '3-5 hrs', icon: '📦' },
      { id: 'packing', name: 'Packing Service', price: 150, duration: '2-3 hrs', icon: '🎁' },
      { id: 'storage', name: 'Storage Solutions', price: 80, duration: 'Per month', icon: '🗄️' },
    ],
  },
  {
    id: 'painting',
    name: 'Painting',
    icon: '🎨',
    color: 'from-orange-500 to-red-500',
    bg: 'bg-orange-50',
    text: 'text-orange-700',
    border: 'border-orange-200',
    subcategories: [
      { id: 'interior', name: 'Interior Painting', price: 400, duration: 'Per room', icon: '🖌️' },
      { id: 'exterior', name: 'Exterior Painting', price: 800, duration: 'Per day', icon: '🏠' },
    ],
  },
  {
    id: 'pest',
    name: 'Pest Control',
    icon: '🐛',
    color: 'from-green-500 to-emerald-500',
    bg: 'bg-green-50',
    text: 'text-green-700',
    border: 'border-green-200',
    subcategories: [
      { id: 'general', name: 'General Pest Control', price: 140, duration: '1-2 hrs', icon: '🦟' },
      { id: 'termite', name: 'Termite Treatment', price: 350, duration: '3-4 hrs', icon: '🐜' },
    ],
  },
];

export const bookingStatuses = [
  { id: 'pending', label: 'Pending', color: 'bg-slate-100 text-slate-700' },
  { id: 'confirmed', label: 'Confirmed', color: 'bg-blue-100 text-blue-700' },
  { id: 'assigned', label: 'Assigned', color: 'bg-indigo-100 text-indigo-700' },
  { id: 'accepted', label: 'Accepted', color: 'bg-violet-100 text-violet-700' },
  { id: 'on_the_way', label: 'On The Way', color: 'bg-amber-100 text-amber-700' },
  { id: 'arrived', label: 'Arrived', color: 'bg-orange-100 text-orange-700' },
  { id: 'started', label: 'Started', color: 'bg-cyan-100 text-cyan-700' },
  { id: 'completed', label: 'Completed', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'cancelled', label: 'Cancelled', color: 'bg-red-100 text-red-700' },
  { id: 'refunded', label: 'Refunded', color: 'bg-rose-100 text-rose-700' },
];

export const sampleCustomers = [
  { id: 'C-001', name: 'Sarah Al-Maktoum', email: 'sarah.al@wasta.ae', phone: '+971 50 123 4567', avatar: '👩', joined: '2024-01-15', totalBookings: 47, totalSpent: 4280, city: 'Dubai' },
  { id: 'C-002', name: 'Mohammed Al-Rashid', email: 'm.rashid@wasta.ae', phone: '+971 50 234 5678', avatar: '👨', joined: '2024-02-20', totalBookings: 32, totalSpent: 2890, city: 'Abu Dhabi' },
  { id: 'C-003', name: 'Fatima Hassan', email: 'f.hassan@wasta.ae', phone: '+971 50 345 6789', avatar: '👩‍🦱', joined: '2024-03-10', totalBookings: 18, totalSpent: 1560, city: 'Dubai' },
  { id: 'C-004', name: 'James O\'Connor', email: 'james.o@wasta.ae', phone: '+971 50 456 7890', avatar: '🧑', joined: '2024-04-05', totalBookings: 9, totalSpent: 890, city: 'Sharjah' },
  { id: 'C-005', name: 'Priya Nair', email: 'p.nair@wasta.ae', phone: '+971 50 567 8901', avatar: '👩‍💼', joined: '2024-05-12', totalBookings: 25, totalSpent: 2100, city: 'Dubai' },
  { id: 'C-006', name: 'Ahmed Bin Ali', email: 'a.ali@wasta.ae', phone: '+971 50 678 9012', avatar: '👳', joined: '2024-06-01', totalBookings: 14, totalSpent: 1340, city: 'Ajman' },
];

export const sampleProviders = [
  { id: 'P-001', name: 'Ahmed Technical Services', category: 'Electrical Services', provider: 'Khalid Ahmed', phone: '+971 52 111 2233', rating: 4.9, jobs: 342, earned: 28400, status: 'verified', avatar: '⚡', city: 'Dubai' },
  { id: 'P-002', name: 'Sparkle Clean Pro', category: 'Cleaning Services', provider: 'Maria Santos', phone: '+971 52 222 3344', rating: 4.8, jobs: 521, earned: 42300, status: 'verified', avatar: '✨', city: 'Dubai' },
  { id: 'P-003', name: 'Quick Plumb 24/7', category: 'Plumbing', provider: 'Raj Kumar', phone: '+971 52 333 4455', rating: 4.7, jobs: 198, earned: 15600, status: 'verified', avatar: '🔧', city: 'Abu Dhabi' },
  { id: 'P-004', name: 'Arctic Cool HVAC', category: 'AC Services', provider: 'Carlos Rivera', phone: '+971 52 444 5566', rating: 4.9, jobs: 412, earned: 38700, status: 'verified', avatar: '❄️', city: 'Dubai' },
  { id: 'P-005', name: 'Glam Studio Home', category: 'Beauty & Salon', provider: 'Aisha Khan', phone: '+971 52 555 6677', rating: 5.0, jobs: 287, earned: 24500, status: 'verified', avatar: '💅', city: 'Dubai' },
  { id: 'P-006', name: 'Swift Movers UAE', category: 'Moving & Packing', provider: 'David Lee', phone: '+971 52 666 7788', rating: 4.6, jobs: 156, earned: 19200, status: 'pending', avatar: '🚚', city: 'Sharjah' },
  { id: 'P-007', name: 'Pro Painters Co', category: 'Painting', provider: 'Luis Torres', phone: '+971 52 777 8899', rating: 4.8, jobs: 189, earned: 21300, status: 'verified', avatar: '🎨', city: 'Dubai' },
  { id: 'P-008', name: 'Pest Shield Experts', category: 'Pest Control', provider: 'Nadia Yusuf', phone: '+971 52 888 9900', rating: 4.7, jobs: 234, earned: 18900, status: 'suspended', avatar: '🐛', city: 'Abu Dhabi' },
];

export const sampleBookings = [
  { id: 'WST-20250001', customer: 'Sarah Al-Maktoum', service: 'Deep Cleaning', provider: 'Sparkle Clean Pro', amount: 180, status: 'completed', date: '2025-01-15', time: '10:00 AM', city: 'Dubai', rating: 5 },
  { id: 'WST-20250002', customer: 'Mohammed Al-Rashid', service: 'AC Repair', provider: 'Arctic Cool HVAC', amount: 120, status: 'on_the_way', date: '2025-01-19', time: '02:00 PM', city: 'Abu Dhabi', rating: null },
  { id: 'WST-20250003', customer: 'Fatima Hassan', service: 'Manicure & Pedicure', provider: 'Glam Studio Home', amount: 95, status: 'started', date: '2025-01-19', time: '03:00 PM', city: 'Dubai', rating: null },
  { id: 'WST-20250004', customer: 'James O\'Connor', service: 'Drain Cleaning', provider: 'Quick Plumb 24/7', amount: 110, status: 'pending', date: '2025-01-20', time: '11:00 AM', city: 'Sharjah', rating: null },
  { id: 'WST-20250005', customer: 'Priya Nair', service: 'Light Installation', provider: 'Ahmed Technical Services', amount: 75, status: 'completed', date: '2025-01-14', time: '09:00 AM', city: 'Dubai', rating: 5 },
  { id: 'WST-20250006', customer: 'Ahmed Bin Ali', service: 'Local Moving', provider: 'Swift Movers UAE', amount: 300, status: 'confirmed', date: '2025-01-21', time: '08:00 AM', city: 'Ajman', rating: null },
  { id: 'WST-20250007', customer: 'Sarah Al-Maktoum', service: 'Premium Facial', provider: 'Glam Studio Home', amount: 120, status: 'completed', date: '2025-01-12', time: '05:00 PM', city: 'Dubai', rating: 5 },
  { id: 'WST-20250008', customer: 'Priya Nair', service: 'Carpet Cleaning', provider: 'Sparkle Clean Pro', amount: 120, status: 'cancelled', date: '2025-01-17', time: '12:00 PM', city: 'Dubai', rating: null },
  { id: 'WST-20250009', customer: 'Mohammed Al-Rashid', service: 'Emergency Repair', provider: 'Ahmed Technical Services', amount: 120, status: 'completed', date: '2025-01-10', time: '06:00 PM', city: 'Abu Dhabi', rating: 4 },
  { id: 'WST-20250010', customer: 'Fatima Hassan', service: 'Water Heater Service', provider: 'Quick Plumb 24/7', amount: 180, status: 'arrived', date: '2025-01-19', time: '01:30 PM', city: 'Dubai', rating: null },
];

export const supportTickets = [
  { id: 'TKT-9001', customer: 'Sarah Al-Maktoum', subject: 'Provider arrived late', priority: 'high', status: 'open', date: '2025-01-19', category: 'Booking Issue' },
  { id: 'TKT-9002', customer: 'James O\'Connor', subject: 'Refund not processed', priority: 'high', status: 'in_progress', date: '2025-01-18', category: 'Payment' },
  { id: 'TKT-9003', customer: 'Priya Nair', subject: 'Can I reschedule my booking?', priority: 'low', status: 'resolved', date: '2025-01-17', category: 'Booking' },
  { id: 'TKT-9004', customer: 'Ahmed Bin Ali', subject: 'Quality of service was poor', priority: 'medium', status: 'escalated', date: '2025-01-18', category: 'Quality' },
  { id: 'TKT-9005', customer: 'Mohammed Al-Rashid', subject: 'Double charge on payment', priority: 'urgent', status: 'open', date: '2025-01-19', category: 'Payment' },
];

export const kpis = [
  { label: 'Total Revenue', value: 'AED 1.24M', change: '+18.2%', positive: true },
  { label: 'Active Bookings', value: '8,420', change: '+12.5%', positive: true },
  { label: 'Active Providers', value: '2,847', change: '+4.8%', positive: true },
  { label: 'Active Customers', value: '142.6K', change: '+22.1%', positive: true },
  { label: 'Completion Rate', value: '96.4%', change: '+1.2%', positive: true },
  { label: 'Avg. Rating', value: '4.82', change: '+0.08', positive: true },
];

export const revenueByMonth = [
  { month: 'Aug', revenue: 180000, bookings: 1200 },
  { month: 'Sep', revenue: 220000, bookings: 1450 },
  { month: 'Oct', revenue: 260000, bookings: 1680 },
  { month: 'Nov', revenue: 310000, bookings: 1920 },
  { month: 'Dec', revenue: 380000, bookings: 2240 },
  { month: 'Jan', revenue: 420000, bookings: 2480 },
];

export const servicesDistribution = [
  { name: 'Cleaning', value: 28, color: '#3b82f6' },
  { name: 'AC Services', value: 22, color: '#0ea5e9' },
  { name: 'Electrical', value: 15, color: '#f59e0b' },
  { name: 'Plumbing', value: 13, color: '#10b981' },
  { name: 'Beauty', value: 12, color: '#ec4899' },
  { name: 'Others', value: 10, color: '#8b5cf6' },
];

export const recentTransactions = [
  { id: 'TX-78291', type: 'Payment', customer: 'Sarah Al-Maktoum', amount: 180, status: 'completed', date: '2 hours ago' },
  { id: 'TX-78292', type: 'Payout', customer: 'Sparkle Clean Pro', amount: 153, status: 'completed', date: '3 hours ago' },
  { id: 'TX-78293', type: 'Refund', customer: 'James O\'Connor', amount: 110, status: 'pending', date: '5 hours ago' },
  { id: 'TX-78294', type: 'Payment', customer: 'Mohammed Al-Rashid', amount: 120, status: 'completed', date: '6 hours ago' },
  { id: 'TX-78295', type: 'Commission', customer: 'Platform Fee', amount: 22, status: 'completed', date: '6 hours ago' },
];
