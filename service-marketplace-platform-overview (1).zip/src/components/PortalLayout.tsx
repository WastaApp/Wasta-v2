import { ReactNode } from 'react';
import Sidebar from './Sidebar';

interface PortalLayoutProps {
  role: 'customer' | 'provider' | 'admin' | 'superadmin' | 'support';
  active: string;
  onChange: (id: string) => void;
  children: ReactNode;
}

export default function PortalLayout({ role, active, onChange, children }: PortalLayoutProps) {
  return (
    <div className="min-h-screen flex bg-slate-50">
      <Sidebar role={role} active={active} onChange={onChange} />
      <main className="flex-1 min-w-0 overflow-y-auto">
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
