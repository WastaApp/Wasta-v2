import { Role, roles } from '../types';
import { cn } from '../lib/utils';
import { LogOut, Bell, Search, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface TopbarProps {
  currentRole: Role;
  onChangeRole: (role: Role) => void;
}

export default function Topbar({ currentRole, onChangeRole }: TopbarProps) {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const role = currentRole !== 'landing' ? roles[currentRole] : null;

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-slate-200/60 shadow-sm">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-900 to-slate-700 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
              <span className="text-white font-black text-sm">W</span>
            </div>
            <div>
              <div className="text-lg font-black text-slate-900 tracking-tight leading-none">WASTA</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider leading-none">Marketplace</div>
            </div>
          </button>

          {/* Role Switcher */}
          {currentRole !== 'landing' && (
            <div className="hidden md:flex items-center gap-1 bg-slate-100 rounded-xl p-1">
              {(['customer', 'provider', 'admin', 'superadmin', 'support'] as Role[]).map((r) => {
                const rd = roles[r as keyof typeof roles];
                return (
                  <button
                    key={r}
                    onClick={() => onChangeRole(r)}
                    className={cn(
                      'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5',
                      currentRole === r
                        ? `bg-white text-slate-900 shadow-sm`
                        : 'text-slate-600 hover:text-slate-900'
                    )}
                  >
                    <span>{rd.icon}</span>
                    <span className="hidden lg:inline">{rd.name}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Right Side */}
          <div className="flex items-center gap-2">
            {currentRole === 'landing' ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('/auth')}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  Login
                </button>
                <button
                  onClick={() => navigate('/auth')}
                  className="px-4 py-2 rounded-xl text-sm font-semibold bg-slate-900 text-white hover:bg-slate-800 transition-colors shadow-lg shadow-slate-500/20"
                >
                  Get Started
                </button>
              </div>
            ) : (
              <>
                <div className="relative hidden sm:block">
                  <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="pl-9 pr-4 py-2 rounded-xl bg-slate-100 text-sm text-slate-700 border-0 focus:outline-none focus:ring-2 focus:ring-slate-900/10 w-40 lg:w-56"
                  />
                </div>

                <button className="relative p-2 rounded-xl hover:bg-slate-100 text-slate-600 transition-colors">
                  <Bell size={18} />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-white" />
                </button>

                <div className="relative">
                  <button
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="flex items-center gap-2 p-1.5 pl-3 rounded-xl hover:bg-slate-100 transition-colors"
                  >
                    <div className="text-right hidden sm:block">
                      <div className="text-sm font-semibold text-slate-900 leading-none">{role?.personName}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{role?.personTitle}</div>
                    </div>
                    <div className={cn('w-9 h-9 rounded-xl bg-gradient-to-br flex items-center justify-center text-lg', role?.gradient)}>
                      {role?.icon}
                    </div>
                    <ChevronDown size={14} className="text-slate-400" />
                  </button>

                  {menuOpen && (
                    <div className="absolute right-0 top-full mt-2 w-56 rounded-2xl bg-white border border-slate-200 shadow-xl p-2 z-50">
                      <div className="px-3 py-2 border-b border-slate-100 mb-1">
                        <div className="text-sm font-semibold text-slate-900">{role?.personName}</div>
                        <div className="text-xs text-slate-500">{role?.personTitle}</div>
                      </div>
                      <button
                        onClick={() => { setMenuOpen(false); navigate('/'); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-700 hover:bg-slate-50 transition-colors"
                      >
                        <LogOut size={16} /> Back to Home
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Mobile role switcher */}
        {currentRole !== 'landing' && (
          <div className="md:hidden flex items-center gap-1 overflow-x-auto pb-2 scrollbar-hide">
            {(['customer', 'provider', 'admin', 'superadmin', 'support'] as Role[]).map((r) => {
              const rd = roles[r as keyof typeof roles];
              return (
                <button
                  key={r}
                  onClick={() => onChangeRole(r)}
                  className={cn(
                    'flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5',
                    currentRole === r ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  )}
                >
                  <span>{rd.icon}</span>
                  {rd.name}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
}
