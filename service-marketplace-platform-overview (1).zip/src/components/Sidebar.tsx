import { cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, ShoppingBag, Calendar, Wallet, MessageSquare,
  Star, User, Heart, LogOut, Briefcase, MapPin, Clock, TrendingUp,
  Award, Users, FileText, Settings, Bell, Shield, Key, Database,
  DollarSign, Tags, Headphones, Ticket, AlertTriangle, BarChart3
} from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon: any;
  badge?: string | number;
  group?: string;
}

export function getNavItems(role: string): NavItem[] {
  switch (role) {
    case 'customer':
      return [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'book', label: 'Book a Service', icon: ShoppingBag },
        { id: 'bookings', label: 'My Bookings', icon: Calendar, badge: 2 },
        { id: 'favorites', label: 'Favorite Pros', icon: Heart },
        { id: 'wallet', label: 'Wallet & Payments', icon: Wallet },
        { id: 'messages', label: 'Messages', icon: MessageSquare, badge: 3 },
        { id: 'reviews', label: 'My Reviews', icon: Star },
        { id: 'profile', label: 'Profile & Addresses', icon: User },
      ];
    case 'provider':
      return [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'jobs', label: 'Available Jobs', icon: Briefcase, badge: 5 },
        { id: 'active', label: 'Active Jobs', icon: Clock },
        { id: 'schedule', label: 'My Schedule', icon: Calendar },
        { id: 'earnings', label: 'Earnings', icon: DollarSign },
        { id: 'ratings', label: 'Ratings', icon: Star },
        { id: 'navigation', label: 'Navigation', icon: MapPin },
        { id: 'profile', label: 'My Profile', icon: Award },
      ];
    case 'admin':
      return [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'bookings', label: 'Bookings', icon: ShoppingBag, badge: 24 },
        { id: 'providers', label: 'Providers', icon: Users },
        { id: 'customers', label: 'Customers', icon: User },
        { id: 'services', label: 'Services', icon: Briefcase },
        { id: 'payments', label: 'Payments', icon: Wallet },
        { id: 'refunds', label: 'Refunds', icon: DollarSign, badge: 8 },
        { id: 'complaints', label: 'Complaints', icon: AlertTriangle, badge: 12 },
        { id: 'reviews', label: 'Reviews', icon: Star },
        { id: 'marketing', label: 'Marketing', icon: Tags },
        { id: 'notifications', label: 'Notifications', icon: Bell },
        { id: 'reports', label: 'Reports', icon: FileText },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'settings', label: 'Settings', icon: Settings },
      ];
    case 'superadmin':
      return [
        { id: 'dashboard', label: 'Executive View', icon: LayoutDashboard },
        { id: 'roles', label: 'Roles & Permissions', icon: Shield },
        { id: 'commission', label: 'Commission Engine', icon: DollarSign },
        { id: 'finance', label: 'Finance Center', icon: Wallet },
        { id: 'feature-flags', label: 'Feature Flags', icon: Key },
        { id: 'audit', label: 'Audit Logs', icon: FileText },
        { id: 'api', label: 'API Management', icon: Database },
        { id: 'regions', label: 'Regions', icon: MapPin },
        { id: 'config', label: 'System Config', icon: Settings },
      ];
    case 'support':
      return [
        { id: 'dashboard', label: 'Support Dashboard', icon: Headphones },
        { id: 'tickets', label: 'Open Tickets', icon: Ticket, badge: 18 },
        { id: 'refunds', label: 'Refund Requests', icon: DollarSign, badge: 6 },
        { id: 'escalations', label: 'Escalations', icon: AlertTriangle, badge: 3 },
        { id: 'chats', label: 'Live Chats', icon: MessageSquare, badge: 5 },
        { id: 'knowledge', label: 'Knowledge Base', icon: FileText },
        { id: 'performance', label: 'My Performance', icon: TrendingUp },
      ];
    default:
      return [];
  }
}

interface SidebarProps {
  role: string;
  active: string;
  onChange: (id: string) => void;
}

export default function Sidebar({ role, active, onChange }: SidebarProps) {
  const items = getNavItems(role);
  const navigate = useNavigate();

  const roleColors: Record<string, string> = {
    customer: 'from-blue-600 to-indigo-600',
    provider: 'from-emerald-600 to-teal-600',
    admin: 'from-violet-600 to-purple-600',
    superadmin: 'from-amber-500 to-orange-600',
    support: 'from-cyan-500 to-blue-600',
  };

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col h-screen sticky top-0 flex-shrink-0">
      <div className="p-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="w-10 h-10 rounded-xl bg-white flex items-center justify-center">
            <span className="text-slate-900 font-black text-lg">W</span>
          </button>
          <div>
            <div className="text-white font-black text-base">WASTA</div>
            <div className="text-[10px] uppercase tracking-wider text-slate-500">
              {role === 'customer' ? 'Customer Portal' :
                role === 'provider' ? 'Provider App' :
                role === 'admin' ? 'Admin Portal' :
                role === 'superadmin' ? 'Super Admin' : 'Support Center'}
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-0.5 scrollbar-hide">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
              active === item.id
                ? `bg-gradient-to-r ${roleColors[role]} text-white shadow-lg`
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            )}
          >
            <item.icon size={18} />
            <span className="flex-1 text-left">{item.label}</span>
            {item.badge && (
              <span className={cn(
                'px-2 py-0.5 rounded-full text-[10px] font-bold',
                active === item.id ? 'bg-white/20 text-white' : 'bg-slate-700 text-slate-300'
              )}>
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-3 border-t border-slate-800">
        <button onClick={() => navigate('/')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-400 hover:bg-slate-800 hover:text-white transition-all">
          <LogOut size={18} /> Back to Home
        </button>
      </div>
    </aside>
  );
}
