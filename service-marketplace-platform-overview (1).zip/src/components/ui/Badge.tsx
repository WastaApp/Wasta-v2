import { cn } from '../../lib/utils';

const styles: Record<string, string> = {
  default: 'bg-slate-100 text-slate-700',
  blue: 'bg-blue-100 text-blue-700',
  emerald: 'bg-emerald-100 text-emerald-700',
  amber: 'bg-amber-100 text-amber-700',
  red: 'bg-red-100 text-red-700',
  violet: 'bg-violet-100 text-violet-700',
  rose: 'bg-rose-100 text-rose-700',
  sky: 'bg-sky-100 text-sky-700',
  indigo: 'bg-indigo-100 text-indigo-700',
};

export default function Badge({
  children,
  color = 'default',
  className,
}: {
  children: React.ReactNode;
  color?: keyof typeof styles;
  className?: string;
}) {
  return (
    <span className={cn('inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-semibold', styles[color], className)}>
      {children}
    </span>
  );
}
