import { useState } from 'react';
import PortalLayout from '../../components/PortalLayout';
import { services, sampleBookings, bookingStatuses } from '../../data/mockData';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { motion } from 'framer-motion';
import {
  ShoppingBag, Calendar, Wallet, Star, User,
  MapPin, Clock, ChevronRight, Plus, Check, Phone, Mail, CreditCard,
  Gift, TrendingUp, Navigation,
} from 'lucide-react';

export default function CustomerPortal() {
  const [active, setActive] = useState('dashboard');
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [bookingStep, setBookingStep] = useState(0);

  const customerBookings = sampleBookings.filter((b) => b.customer === 'Sarah Al-Maktoum');
  const activeBookings = customerBookings.filter((b) => !['completed', 'cancelled', 'refunded'].includes(b.status));
  const pastBookings = customerBookings.filter((b) => ['completed', 'cancelled', 'refunded'].includes(b.status));

  return (
    <PortalLayout role="customer" active={active} onChange={setActive}>
      {active === 'dashboard' && (
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: <ShoppingBag />, label: 'Book Service', color: 'from-blue-600 to-indigo-600', action: () => setActive('book') },
              { icon: <Calendar />, label: 'My Bookings', color: 'from-violet-600 to-purple-600', count: activeBookings.length, action: () => setActive('bookings') },
              { icon: <Wallet />, label: 'Wallet', color: 'from-emerald-600 to-teal-600', value: 'AED 245' },
              { icon: <Gift />, label: 'Loyalty Points', color: 'from-amber-500 to-orange-500', value: '1,240 pts' },
            ].map((a) => (
              <button key={a.label} onClick={a.action} className="group relative overflow-hidden rounded-2xl bg-white p-5 border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all text-left">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${a.color} flex items-center justify-center text-white mb-3 group-hover:scale-110 transition-transform`}>
                  {a.icon}
                </div>
                <div className="text-sm font-semibold text-slate-900">{a.label}</div>
                {a.value && <div className="text-xs text-slate-500 mt-0.5">{a.value}</div>}
                {a.count !== undefined && <div className="text-xs text-slate-500 mt-0.5">{a.count} active</div>}
              </button>
            ))}
          </div>

          {/* Active Bookings */}
          {activeBookings.length > 0 && (
            <Card>
              <CardHeader
                title="Active Bookings"
                subtitle="Track your ongoing services"
                action={<button onClick={() => setActive('bookings')} className="text-sm text-blue-600 font-semibold flex items-center gap-1">View all <ChevronRight size={14} /></button>}
              />
              <CardBody>
                <div className="space-y-3">
                  {activeBookings.map((b) => {
                    const status = bookingStatuses.find((s) => s.id === b.status);
                    return (
                      <motion.div key={b.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-4 p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100">
                        <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-2xl">🛠️</div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-slate-900">{b.service}</div>
                          <div className="text-xs text-slate-500">{b.provider} · {b.date} at {b.time}</div>
                        </div>
                        <div className="hidden sm:block text-right">
                          <div className="text-sm font-bold text-slate-900">AED {b.amount}</div>
                          <Badge color={b.status === 'on_the_way' ? 'amber' : b.status === 'started' ? 'sky' : 'blue'}>{status?.label}</Badge>
                        </div>
                        {b.status === 'on_the_way' && (
                          <button className="p-2.5 rounded-xl bg-blue-600 text-white hover:bg-blue-700"><Navigation size={18} /></button>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </CardBody>
            </Card>
          )}

          {/* Popular Services */}
          <Card>
            <CardHeader title="Popular Services" subtitle="Frequently booked in your area" />
            <CardBody>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {services.slice(0, 8).map((s) => (
                  <button key={s.id} onClick={() => { setSelectedService(s.id); setBookingStep(0); setActive('book'); }} className="group p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all text-left">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center text-2xl mb-3 group-hover:scale-110 transition-transform`}>{s.icon}</div>
                    <div className="text-sm font-semibold text-slate-900 truncate">{s.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">from AED {Math.min(...s.subcategories.map(x => x.price))}</div>
                  </button>
                ))}
              </div>
            </CardBody>
          </Card>

          {/* Recent */}
          <Card>
            <CardHeader title="Recent Bookings" />
            <CardBody>
              <div className="space-y-2">
                {pastBookings.slice(0, 4).map((b) => (
                  <div key={b.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">✅</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900 truncate">{b.service}</div>
                      <div className="text-xs text-slate-500">{b.date} · {b.provider}</div>
                    </div>
                    {b.rating && <div className="text-amber-500 text-xs font-bold flex items-center gap-0.5"><Star size={12} fill="currentColor" />{b.rating}</div>}
                    <div className="text-sm font-semibold text-slate-700">AED {b.amount}</div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'book' && (
        <BookingFlow selectedService={selectedService} setSelectedService={setSelectedService} bookingStep={bookingStep} setBookingStep={setBookingStep} />
      )}

      {active === 'bookings' && (
        <div className="space-y-6">
          <div className="flex gap-2 mb-4">
            {['All', 'Active', 'Completed'].map((f, i) => (
              <button key={f} className={`px-4 py-2 rounded-xl text-sm font-semibold ${i === 0 ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-700'}`}>{f}</button>
            ))}
          </div>
          <Card>
            <CardBody>
              <div className="space-y-3">
                {customerBookings.map((b) => {
                  const status = bookingStatuses.find((s) => s.id === b.status);
                  return (
                    <div key={b.id} className="flex items-center gap-4 p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-sm transition-all">
                      <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-2xl">🔧</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-slate-900">{b.service}</span>
                          <Badge color={b.status === 'completed' ? 'emerald' : b.status === 'cancelled' ? 'red' : 'blue'}>{status?.label}</Badge>
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-3 mt-1 flex-wrap">
                          <span className="flex items-center gap-1"><Calendar size={11} />{b.date}</span>
                          <span className="flex items-center gap-1"><Clock size={11} />{b.time}</span>
                          <span className="flex items-center gap-1"><MapPin size={11} />{b.city}</span>
                          <span>{b.provider}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1 font-mono">{b.id}</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="font-bold text-slate-900">AED {b.amount}</div>
                        <Button size="sm" variant="ghost">Details</Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'profile' && (
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardBody className="text-center">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-4xl mb-4">👩</div>
              <h3 className="text-xl font-bold text-slate-900">Sarah Al-Maktoum</h3>
              <p className="text-sm text-slate-500">Customer since Jan 2024</p>
              <div className="grid grid-cols-3 gap-2 mt-5 pt-5 border-t border-slate-100">
                <div><div className="text-lg font-bold">47</div><div className="text-xs text-slate-500">Bookings</div></div>
                <div><div className="text-lg font-bold">AED 4,280</div><div className="text-xs text-slate-500">Spent</div></div>
                <div><div className="text-lg font-bold">4.9★</div><div className="text-xs text-slate-500">Rating</div></div>
              </div>
            </CardBody>
          </Card>
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader title="Personal Information" />
              <CardBody className="space-y-3">
                {[
                  { icon: User, label: 'Full Name', value: 'Sarah Al-Maktoum' },
                  { icon: Phone, label: 'Phone', value: '+971 50 123 4567' },
                  { icon: Mail, label: 'Email', value: 'sarah.al@wasta.ae' },
                ].map((f) => (
                  <div key={f.label} className="flex items-center gap-4 p-3 rounded-xl bg-slate-50">
                    <f.icon size={18} className="text-slate-400" />
                    <div className="flex-1"><div className="text-xs text-slate-500">{f.label}</div><div className="text-sm font-medium text-slate-900">{f.value}</div></div>
                    <ChevronRight size={16} className="text-slate-400" />
                  </div>
                ))}
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Saved Addresses" action={<Button size="sm" variant="outline"><Plus size={14} />Add</Button>} />
              <CardBody className="space-y-3">
                {[
                  { name: 'Home', address: 'Marina Tower, Dubai Marina', default: true },
                  { name: 'Office', address: 'DIFC Gate Village, Dubai' },
                ].map((a) => (
                  <div key={a.name} className="flex items-center gap-3 p-3 rounded-xl border border-slate-200">
                    <MapPin size={18} className="text-blue-600" />
                    <div className="flex-1"><div className="text-sm font-medium">{a.name}{a.default && <span className="ml-2 text-xs text-emerald-600">Default</span>}</div><div className="text-xs text-slate-500">{a.address}</div></div>
                  </div>
                ))}
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Payment Methods" action={<Button size="sm" variant="outline"><Plus size={14} />Add</Button>} />
              <CardBody className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-xl border border-slate-200">
                  <CreditCard size={18} className="text-indigo-600" />
                  <div className="flex-1"><div className="text-sm font-medium">Visa •••• 4829</div><div className="text-xs text-slate-500">Expires 08/27</div></div>
                  <Check size={18} className="text-emerald-500" />
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {active === 'wallet' && (
        <div className="space-y-6">
          <Card className="bg-gradient-to-br from-slate-900 to-slate-700 text-white border-0">
            <CardBody className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="text-slate-400 text-sm">Wallet Balance</div>
                  <div className="text-4xl font-black mt-1">AED 245.00</div>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center"><Wallet size={24} /></div>
              </div>
              <div className="flex gap-2"><Button variant="secondary">Top Up</Button><Button variant="outline" className="border-white/20 text-white hover:bg-white/10">Withdraw</Button></div>
            </CardBody>
          </Card>
          <Card>
            <CardHeader title="Transaction History" />
            <CardBody>
              <div className="space-y-2">
                {[
                  { desc: 'Deep Cleaning · Sparkle Clean Pro', date: 'Jan 15, 2025', amount: -180, type: 'Payment' },
                  { desc: 'Wallet Top-up', date: 'Jan 14, 2025', amount: 500, type: 'Top-up' },
                  { desc: 'Referral Bonus', date: 'Jan 10, 2025', amount: 50, type: 'Bonus' },
                  { desc: 'Light Installation · Ahmed Tech', date: 'Jan 8, 2025', amount: -75, type: 'Payment' },
                ].map((t, i) => (
                  <div key={i} className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${t.amount > 0 ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}>
                      <TrendingUp size={18} className={t.amount > 0 ? '' : 'rotate-180'} />
                    </div>
                    <div className="flex-1"><div className="text-sm font-medium">{t.desc}</div><div className="text-xs text-slate-500">{t.date} · {t.type}</div></div>
                    <div className={`font-bold ${t.amount > 0 ? 'text-emerald-600' : 'text-slate-900'}`}>{t.amount > 0 ? '+' : ''}AED {Math.abs(t.amount)}</div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'favorites' && (
        <Card>
          <CardHeader title="Favorite Providers" subtitle="Your go-to service professionals" />
          <CardBody>
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { name: 'Sparkle Clean Pro', service: 'Cleaning', rating: 4.8, jobs: 521, icon: '✨' },
                { name: 'Glam Studio Home', service: 'Beauty', rating: 5.0, jobs: 287, icon: '💅' },
                { name: 'Ahmed Technical Services', service: 'Electrical', rating: 4.9, jobs: 342, icon: '⚡' },
              ].map((p) => (
                <div key={p.name} className="flex items-center gap-4 p-4 rounded-xl border border-slate-200">
                  <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-2xl">{p.icon}</div>
                  <div className="flex-1"><div className="font-semibold">{p.name}</div><div className="text-xs text-slate-500">{p.service} · <Star size={11} className="inline text-amber-500" fill="currentColor" />{p.rating} · {p.jobs} jobs</div></div>
                  <Button size="sm">Book</Button>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'messages' && (
        <Card>
          <CardHeader title="Messages" subtitle="3 unread conversations" />
          <CardBody>
            <div className="space-y-2">
              {[
                { name: 'Maria (Sparkle Clean Pro)', msg: 'On my way, be there in 10 minutes!', unread: true, time: '2 min ago', icon: '✨' },
                { name: 'Support Team', msg: 'Your refund has been processed.', unread: true, time: '1 hr ago', icon: '🎧' },
                { name: 'Khalid (Ahmed Tech)', msg: 'Thanks for the great review!', unread: true, time: '3 hrs ago', icon: '⚡' },
                { name: 'Carlos (Arctic Cool)', msg: 'Service completed. Please leave a review.', unread: false, time: 'Yesterday', icon: '❄️' },
              ].map((m, i) => (
                <div key={i} className={`flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 ${m.unread ? 'bg-blue-50' : ''}`}>
                  <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center text-xl relative">
                    {m.icon}
                    {m.unread && <div className="absolute top-0 right-0 w-3 h-3 rounded-full bg-blue-500 ring-2 ring-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between"><div className="text-sm font-semibold truncate">{m.name}</div><div className="text-xs text-slate-400">{m.time}</div></div>
                    <div className="text-xs text-slate-500 truncate">{m.msg}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'reviews' && (
        <Card>
          <CardHeader title="My Reviews" />
          <CardBody className="space-y-4">
            {[
              { service: 'Deep Cleaning', provider: 'Sparkle Clean Pro', rating: 5, date: 'Jan 15, 2025', text: 'Maria was amazing! So thorough and professional. Will definitely book again!' },
              { service: 'Light Installation', provider: 'Ahmed Technical Services', rating: 5, date: 'Jan 14, 2025', text: 'Khalid did an excellent job installing all our new LED lights. Quick and clean work.' },
            ].map((r, i) => (
              <div key={i} className="p-4 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-semibold">{r.service}</div>
                  <div className="flex text-amber-500">{Array(r.rating).fill(0).map((_, j) => <Star key={j} size={14} fill="currentColor" />)}</div>
                </div>
                <div className="text-xs text-slate-500 mb-2">{r.provider} · {r.date}</div>
                <div className="text-sm text-slate-700">{r.text}</div>
              </div>
            ))}
          </CardBody>
        </Card>
      )}
    </PortalLayout>
  );
}

function BookingFlow({ selectedService, setSelectedService, bookingStep, setBookingStep }: any) {
  const currentService = services.find((s) => s.id === selectedService);

  if (!currentService) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">What service do you need?</h2>
          <p className="text-slate-500">Select from 50+ professional services across the UAE.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {services.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelectedService(s.id)}
              className="group text-left p-6 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all"
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform`}>
                {s.icon}
              </div>
              <div className="font-bold text-slate-900 mb-1">{s.name}</div>
              <div className="text-xs text-slate-500">{s.subcategories.length} sub-services</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  const steps = ['Service', 'Details', 'Schedule', 'Location', 'Payment', 'Confirm'];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Progress */}
      <div className="flex items-center gap-2 mb-2 overflow-x-auto pb-2">
        {steps.map((s, i) => (
          <div key={s} className="flex items-center gap-2 flex-shrink-0">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${i <= bookingStep ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-400'}`}>
              {i < bookingStep ? <Check size={14} /> : i + 1}
            </div>
            <span className={`text-xs font-medium ${i === bookingStep ? 'text-slate-900' : 'text-slate-400'}`}>{s}</span>
            {i < steps.length - 1 && <div className={`w-6 h-0.5 ${i < bookingStep ? 'bg-slate-900' : 'bg-slate-200'}`} />}
          </div>
        ))}
      </div>

      <Card>
        <CardHeader title={currentService.name} subtitle={bookingStep === 0 ? 'Select a sub-service' : `Step ${bookingStep + 1} of ${steps.length}`} />
        <CardBody>
          {bookingStep === 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentService.subcategories.map((sub) => (
                <button key={sub.id} onClick={() => setBookingStep(1)} className="text-left p-4 rounded-xl border border-slate-200 hover:border-slate-900 hover:shadow-md transition-all">
                  <div className="text-2xl mb-2">{sub.icon}</div>
                  <div className="font-semibold text-slate-900">{sub.name}</div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-slate-500">{sub.duration}</span>
                    <span className="font-bold text-slate-900">AED {sub.price}</span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {bookingStep === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2">Service Details</label>
                <textarea placeholder="Describe what you need..." rows={3} className="w-full p-3 rounded-xl border border-slate-200 focus:border-slate-900 focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Upload Photos (optional)</label>
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center text-slate-400 text-sm">
                  <Plus size={24} className="mx-auto mb-2" />
                  Tap to upload photos
                </div>
              </div>
              <Button onClick={() => setBookingStep(2)} className="w-full">Continue</Button>
            </div>
          )}

          {bookingStep === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {['Today', 'Tomorrow', 'Thu 23', 'Fri 24'].map((d) => (
                  <button key={d} className="p-4 rounded-xl border border-slate-200 hover:border-slate-900 hover:bg-slate-50 text-sm font-semibold">{d}</button>
                ))}
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Select Time</label>
                <div className="grid grid-cols-4 gap-2">
                  {['9 AM', '10 AM', '11 AM', '12 PM', '2 PM', '3 PM', '4 PM', '5 PM'].map((t) => (
                    <button key={t} className="p-2 rounded-xl border border-slate-200 hover:border-slate-900 text-sm font-medium">{t}</button>
                  ))}
                </div>
              </div>
              <Button onClick={() => setBookingStep(3)} className="w-full">Continue</Button>
            </div>
          )}

          {bookingStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200">
                <MapPin className="text-blue-600" size={20} />
                <div className="flex-1"><div className="text-xs text-slate-500">Address</div><div className="text-sm font-semibold">Marina Tower, Dubai Marina</div></div>
                <Button size="sm" variant="ghost">Change</Button>
              </div>
              <Button onClick={() => setBookingStep(4)} className="w-full">Continue</Button>
            </div>
          )}

          {bookingStep === 4 && (
            <div className="space-y-4">
              <div className="space-y-2">
                {['Credit Card •••• 4829', 'Apple Pay', 'Google Pay', 'Cash on Delivery'].map((p, i) => (
                  <label key={p} className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                    <input type="radio" name="payment" defaultChecked={i === 0} className="w-4 h-4" />
                    <span className="text-sm font-medium">{p}</span>
                  </label>
                ))}
              </div>
              <div className="p-4 rounded-xl bg-slate-50 space-y-2">
                <div className="flex justify-between text-sm"><span>Service Fee</span><span>AED 180</span></div>
                <div className="flex justify-between text-sm"><span>Platform Fee</span><span>AED 10</span></div>
                <div className="flex justify-between text-sm"><span>VAT (5%)</span><span>AED 9.50</span></div>
                <div className="flex justify-between font-bold pt-2 border-t border-slate-200"><span>Total</span><span>AED 199.50</span></div>
              </div>
              <Button onClick={() => setBookingStep(5)} className="w-full">Pay AED 199.50</Button>
            </div>
          )}

          {bookingStep === 5 && (
            <div className="text-center py-8">
              <div className="w-20 h-20 mx-auto rounded-full bg-emerald-100 flex items-center justify-center mb-4">
                <Check size={40} className="text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Booking Confirmed!</h3>
              <p className="text-slate-500 mb-6">We're matching you with the best professional...</p>
              <div className="p-4 rounded-xl bg-slate-50 text-left space-y-1 text-sm mb-6">
                <div className="flex justify-between"><span className="text-slate-500">Booking ID</span><span className="font-mono font-semibold">WST-20250011</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Service</span><span className="font-semibold">{currentService.name}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Time</span><span className="font-semibold">Tomorrow, 10:00 AM</span></div>
              </div>
              <Button onClick={() => { setBookingStep(0); setSelectedService(null); }}>Done</Button>
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
