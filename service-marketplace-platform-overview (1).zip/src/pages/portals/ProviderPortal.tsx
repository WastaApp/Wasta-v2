import { useState } from 'react';
import PortalLayout from '../../components/PortalLayout';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { sampleBookings } from '../../data/mockData';
import {
  TrendingUp, DollarSign, Calendar, Star, Navigation, CheckCircle2,
  XCircle, Clock, MapPin, Phone, Award, Shield, FileCheck, Briefcase,
} from 'lucide-react';

export default function ProviderPortal() {
  const [active, setActive] = useState('dashboard');

  const availableJobs = [
    { id: 'WST-AV1', service: 'Deep Cleaning', customer: 'Sarah Al-Maktoum', location: 'Dubai Marina', distance: '2.3 km', pay: 162, time: 'Today, 3:00 PM' },
    { id: 'WST-AV2', service: 'Emergency Repair', customer: 'James O\'Connor', location: 'Jumeirah Village', distance: '5.1 km', pay: 108, time: 'Today, 5:30 PM' },
    { id: 'WST-AV3', service: 'Light Installation', customer: 'Priya Nair', location: 'Downtown Dubai', distance: '8.7 km', pay: 67, time: 'Tomorrow, 10:00 AM' },
    { id: 'WST-AV4', service: 'Panel Upgrade', customer: 'Ahmed Bin Ali', location: 'Deira', distance: '12 km', pay: 315, time: 'Tomorrow, 2:00 PM' },
    { id: 'WST-AV5', service: 'House Wiring', customer: 'Fatima Hassan', location: 'Mirdif', distance: '15 km', pay: 180, time: 'Fri, 9:00 AM' },
  ];

  const activeJobs = sampleBookings.filter(b => b.provider === 'Ahmed Technical Services' && ['on_the_way', 'arrived', 'started', 'accepted'].includes(b.status));

  return (
    <PortalLayout role="provider" active={active} onChange={setActive}>
      {active === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Today\'s Earnings', value: 'AED 845', change: '+23%', icon: <DollarSign />, color: 'from-emerald-600 to-teal-600' },
              { label: 'Jobs This Week', value: '12', change: '+3', icon: <Briefcase />, color: 'from-blue-600 to-indigo-600' },
              { label: 'Acceptance Rate', value: '94%', change: '+2%', icon: <CheckCircle2 />, color: 'from-violet-600 to-purple-600' },
              { label: 'Rating', value: '4.9', change: '★ 342', icon: <Star />, color: 'from-amber-500 to-orange-500' },
            ].map((k) => (
              <div key={k.label} className="bg-white rounded-2xl p-5 border border-slate-200">
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${k.color} flex items-center justify-center text-white mb-3`}>{k.icon}</div>
                <div className="text-xs text-slate-500 mb-1">{k.label}</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-black text-slate-900">{k.value}</span>
                  <span className="text-xs font-semibold text-emerald-600 flex items-center gap-0.5"><TrendingUp size={10} />{k.change}</span>
                </div>
              </div>
            ))}
          </div>

          <Card>
            <CardHeader title="Job Requests" subtitle="Accept jobs near you" action={<Badge color="emerald">{availableJobs.length} available</Badge>} />
            <CardBody>
              <div className="space-y-3">
                {availableJobs.slice(0, 3).map((j) => (
                  <div key={j.id} className="flex items-center gap-4 p-4 rounded-xl border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all">
                    <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center text-2xl">⚡</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{j.service}</span>
                        <span className="text-xs text-slate-500 flex items-center gap-1"><MapPin size={11} />{j.distance}</span>
                      </div>
                      <div className="text-xs text-slate-500">{j.customer} · {j.location}</div>
                      <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5"><Clock size={10} />{j.time}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="font-bold text-emerald-600 text-lg">AED {j.pay}</div>
                      <div className="text-[10px] text-slate-400">You earn</div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <button className="p-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700" title="Accept"><CheckCircle2 size={16} /></button>
                      <button className="p-2 rounded-lg bg-slate-100 text-slate-500 hover:bg-red-100 hover:text-red-600" title="Decline"><XCircle size={16} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>

          {activeJobs.length > 0 && (
            <Card>
              <CardHeader title="Active Job" />
              <CardBody>
                {activeJobs.slice(0, 1).map((j) => (
                  <div key={j.id} className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-1">On The Way</div>
                        <div className="font-bold text-lg">{j.service}</div>
                        <div className="text-sm text-slate-600">{j.customer} · {j.city}</div>
                      </div>
                      <Badge color="emerald">AED {Math.round(j.amount * 0.9)}</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <button className="flex items-center justify-center gap-2 p-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold hover:bg-slate-50"><Phone size={14} />Call</button>
                      <button className="flex items-center justify-center gap-2 p-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold hover:bg-slate-50"><MapPin size={14} />Map</button>
                      <button className="flex items-center justify-center gap-2 p-3 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"><CheckCircle2 size={14} />Arrived</button>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full" style={{ width: '60%' }} />
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 mt-2">
                      <span>En route</span><span>Arrival in 8 min</span>
                    </div>
                  </div>
                ))}
              </CardBody>
            </Card>
          )}
        </div>
      )}

      {active === 'jobs' && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <button className="px-4 py-2 rounded-xl bg-slate-900 text-white text-sm font-semibold">All ({availableJobs.length})</button>
            <button className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-semibold">Near Me (3)</button>
            <button className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-sm font-semibold">High Pay (2)</button>
          </div>
          {availableJobs.map((j) => (
            <Card key={j.id}>
              <CardBody>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center text-2xl">⚡</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold">{j.service}</div>
                    <div className="text-xs text-slate-500">{j.customer} · {j.location} · {j.distance} away</div>
                    <div className="text-xs text-slate-400">{j.time}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-emerald-600">AED {j.pay}</div>
                    <div className="flex gap-1 mt-2">
                      <Button size="sm">Accept</Button>
                      <Button size="sm" variant="ghost">Decline</Button>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {active === 'earnings' && (
        <div className="space-y-6">
          <Card className="bg-gradient-to-br from-emerald-600 to-teal-600 text-white border-0">
            <CardBody className="p-8">
              <div className="text-sm opacity-80 mb-1">Total Earnings (Jan 2025)</div>
              <div className="text-4xl font-black mb-4">AED 8,420.50</div>
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/20">
                <div><div className="text-xs opacity-70">Jobs</div><div className="text-xl font-bold">32</div></div>
                <div><div className="text-xs opacity-70">Avg/Job</div><div className="text-xl font-bold">AED 263</div></div>
                <div><div className="text-xs opacity-70">Hours</div><div className="text-xl font-bold">96</div></div>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Payout History" />
            <CardBody>
              <div className="space-y-3">
                {[
                  { date: 'Jan 15, 2025', amount: 2340, status: 'Paid', ref: 'STK-2931' },
                  { date: 'Jan 8, 2025', amount: 1890, status: 'Paid', ref: 'STK-2820' },
                  { date: 'Jan 1, 2025', amount: 2240, status: 'Paid', ref: 'STK-2710' },
                  { date: 'Pending', amount: 1950, status: 'Pending', ref: 'STK-3010' },
                ].map((p) => (
                  <div key={p.ref} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                    <div>
                      <div className="font-semibold text-sm">AED {p.amount.toLocaleString()}</div>
                      <div className="text-xs text-slate-500">{p.date} · {p.ref}</div>
                    </div>
                    <Badge color={p.status === 'Paid' ? 'emerald' : 'amber'}>{p.status}</Badge>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'ratings' && (
        <div className="grid lg:grid-cols-3 gap-6">
          <Card>
            <CardBody className="text-center py-8">
              <div className="text-6xl font-black text-amber-500">4.9</div>
              <div className="flex justify-center text-amber-500 my-2">
                {Array(5).fill(0).map((_, i) => <Star key={i} size={20} fill="currentColor" />)}
              </div>
              <div className="text-sm text-slate-500">From 342 jobs</div>
            </CardBody>
          </Card>
          <div className="lg:col-span-2 space-y-3">
            {[
              { customer: 'Sarah A.', rating: 5, text: 'Excellent work! Very professional and arrived on time.', date: '2 days ago' },
              { customer: 'Priya N.', rating: 5, text: 'Khalid is fantastic. Best electrician in Dubai!', date: '5 days ago' },
              { customer: 'Mohammed R.', rating: 4, text: 'Good work but slightly late.', date: '1 week ago' },
            ].map((r, i) => (
              <Card key={i}>
                <CardBody>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold">{r.customer}</span>
                    <div className="flex text-amber-500">{Array(r.rating).fill(0).map((_, j) => <Star key={j} size={13} fill="currentColor" />)}</div>
                  </div>
                  <p className="text-sm text-slate-700 mb-2">{r.text}</p>
                  <div className="text-xs text-slate-400">{r.date}</div>
                </CardBody>
              </Card>
            ))}
          </div>
        </div>
      )}

      {active === 'schedule' && (
        <Card>
          <CardHeader title="My Schedule" subtitle="Manage your availability" action={<Button size="sm">Set Hours</Button>} />
          <CardBody>
            <div className="grid grid-cols-7 gap-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => (
                <div key={d} className="text-center">
                  <div className="text-xs font-semibold text-slate-500 mb-2">{d}</div>
                  <div className={`p-3 rounded-xl border-2 ${i === 3 || i === 4 ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200'}`}>
                    {i === 3 ? <><div className="text-xs font-bold text-slate-900">3 Jobs</div><div className="text-[10px] text-slate-500">Booked</div></> :
                      i === 4 ? <><div className="text-xs font-bold text-slate-900">2 Jobs</div><div className="text-[10px] text-slate-500">Booked</div></> :
                        <><div className="text-xs text-slate-400">Off</div></>}
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'profile' && (
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardBody className="text-center">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-bold">Khalid Ahmed</h3>
              <p className="text-sm text-slate-500 mb-4">Ahmed Technical Services</p>
              <Badge color="emerald"><Shield size={12} />Verified Pro</Badge>
            </CardBody>
          </Card>
          <div className="lg:col-span-2 space-y-4">
            <Card>
              <CardHeader title="Documents" />
              <CardBody className="space-y-2">
                {[
                  { doc: 'Trade License', status: 'verified', icon: <FileCheck size={16} className="text-emerald-600" /> },
                  { doc: 'Emirates ID', status: 'verified', icon: <Shield size={16} className="text-emerald-600" /> },
                  { doc: 'Passport', status: 'verified', icon: <FileCheck size={16} className="text-emerald-600" /> },
                  { doc: 'Insurance', status: 'verified', icon: <Award size={16} className="text-emerald-600" /> },
                  { doc: 'Bank Details', status: 'verified', icon: <FileCheck size={16} className="text-emerald-600" /> },
                ].map((d) => (
                  <div key={d.doc} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                    {d.icon}
                    <span className="flex-1 text-sm font-medium">{d.doc}</span>
                    <Badge color="emerald">Verified</Badge>
                  </div>
                ))}
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Service Areas" />
              <CardBody>
                <div className="flex flex-wrap gap-2">
                  {['Dubai Marina', 'JBR', 'Palm Jumeirah', 'Downtown', 'Business Bay', 'JVC'].map((area) => (
                    <Badge key={area} color="emerald">{area}</Badge>
                  ))}
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {active === 'navigation' && (
        <Card>
          <CardHeader title="Live Navigation" subtitle="Current route to job location" />
          <CardBody>
            <div className="aspect-video rounded-2xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0" style={{
                backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 30px, rgba(0,0,0,0.05) 30px, rgba(0,0,0,0.05) 31px), repeating-linear-gradient(90deg, transparent, transparent 30px, rgba(0,0,0,0.05) 30px, rgba(0,0,0,0.05) 31px)'
              }} />
              <div className="relative bg-white rounded-2xl shadow-2xl p-6 text-center">
                <Navigation size={40} className="mx-auto text-blue-600 mb-2" />
                <div className="font-bold">Arriving in 8 minutes</div>
                <div className="text-sm text-slate-500">1.2 km remaining</div>
              </div>
            </div>
            <div className="mt-4 p-4 rounded-xl bg-emerald-50 flex items-center gap-4">
              <Calendar className="text-emerald-600" size={20} />
              <div className="flex-1">
                <div className="text-sm font-semibold">Sarah Al-Maktoum</div>
                <div className="text-xs text-slate-500 flex items-center gap-1"><MapPin size={10} />Marina Tower, Dubai Marina</div>
              </div>
              <Button size="sm">Start Nav</Button>
            </div>
          </CardBody>
        </Card>
      )}
    </PortalLayout>
  );
}
