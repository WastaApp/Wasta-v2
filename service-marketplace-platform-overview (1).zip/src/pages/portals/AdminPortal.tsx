import { useState } from 'react';
import PortalLayout from '../../components/PortalLayout';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { sampleBookings, sampleProviders, sampleCustomers, kpis, revenueByMonth, servicesDistribution, recentTransactions, supportTickets, services } from '../../data/mockData';
import { bookingStatuses } from '../../data/mockData';
import {
  TrendingUp, TrendingDown, Search,
  CheckCircle2, XCircle, Eye, MoreVertical, AlertTriangle,
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';

export default function AdminPortal() {
  const [active, setActive] = useState('dashboard');
  const [search, setSearch] = useState('');

  return (
    <PortalLayout role="admin" active={active} onChange={setActive}>
      {active === 'dashboard' && (
        <div className="space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
            {kpis.map((kpi) => (
              <div key={kpi.label} className="bg-white rounded-2xl p-4 border border-slate-200">
                <div className="text-xs text-slate-500 mb-2">{kpi.label}</div>
                <div className="text-xl font-black text-slate-900">{kpi.value}</div>
                <div className={`flex items-center gap-1 text-xs mt-1 font-semibold ${kpi.positive ? 'text-emerald-600' : 'text-red-600'}`}>
                  {kpi.positive ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                  {kpi.change}
                </div>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader title="Revenue Overview" subtitle="Last 6 months" />
              <CardBody>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={revenueByMonth}>
                      <defs>
                        <linearGradient id="cRev" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.3} />
                          <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(v) => `${v / 1000}k`} />
                      <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                      <Area type="monotone" dataKey="revenue" stroke="#8b5cf6" strokeWidth={3} fill="url(#cRev)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Service Mix" />
              <CardBody>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={servicesDistribution} dataKey="value" innerRadius={50} outerRadius={80} paddingAngle={3}>
                        {servicesDistribution.map((d, i) => <Cell key={i} fill={d.color} />)}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-1 mt-4">
                  {servicesDistribution.map((s) => (
                    <div key={s.name} className="flex items-center gap-1.5 text-xs">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                      <span className="text-slate-600">{s.name}</span>
                      <span className="text-slate-400 ml-auto">{s.value}%</span>
                    </div>
                  ))}
                </div>
              </CardBody>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader title="Bookings Trend" />
              <CardBody>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={revenueByMonth}>
                      <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} />
                      <Tooltip contentStyle={{ borderRadius: 12 }} />
                      <Bar dataKey="bookings" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Recent Transactions" action={<Button size="sm" variant="ghost">View all</Button>} />
              <CardBody>
                <div className="space-y-2">
                  {recentTransactions.map((t) => (
                    <div key={t.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold ${
                        t.type === 'Payment' ? 'bg-emerald-100 text-emerald-700' :
                        t.type === 'Payout' ? 'bg-blue-100 text-blue-700' :
                        t.type === 'Refund' ? 'bg-red-100 text-red-700' : 'bg-violet-100 text-violet-700'
                      }`}>
                        {t.type[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{t.customer}</div>
                        <div className="text-xs text-slate-500">{t.type} · {t.date}</div>
                      </div>
                      <div className={`text-sm font-bold ${t.type === 'Refund' ? 'text-red-600' : 'text-slate-900'}`}>
                        AED {t.amount}
                      </div>
                    </div>
                  ))}
                </div>
              </CardBody>
            </Card>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader title="Top Providers" />
              <CardBody className="space-y-3">
                {sampleProviders.slice(0, 4).map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-lg">{p.avatar}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{p.name}</div>
                      <div className="text-xs text-slate-500">{p.jobs} jobs · {p.rating}★</div>
                    </div>
                    <Badge color="emerald">AED {p.earned.toLocaleString()}</Badge>
                  </div>
                ))}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Open Complaints" action={<Badge color="red">{supportTickets.filter(t => t.status !== 'resolved').length}</Badge>} />
              <CardBody className="space-y-3">
                {supportTickets.filter(t => t.status !== 'resolved').slice(0, 4).map((t) => (
                  <div key={t.id} className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${t.priority === 'urgent' ? 'bg-red-100' : t.priority === 'high' ? 'bg-amber-100' : 'bg-slate-100'}`}>
                      <AlertTriangle size={14} className={t.priority === 'urgent' ? 'text-red-600' : t.priority === 'high' ? 'text-amber-600' : 'text-slate-600'} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{t.subject}</div>
                      <div className="text-xs text-slate-500">{t.customer}</div>
                    </div>
                  </div>
                ))}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="System Status" />
              <CardBody className="space-y-2">
                {[
                  { label: 'API Gateway', status: 'Operational', color: 'emerald' },
                  { label: 'Payment Engine', status: 'Operational', color: 'emerald' },
                  { label: 'Notification Hub', status: 'Degraded', color: 'amber' },
                  { label: 'GPS Tracking', status: 'Operational', color: 'emerald' },
                  { label: 'Search Service', status: 'Operational', color: 'emerald' },
                ].map((s) => (
                  <div key={s.label} className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                    <span className="text-sm font-medium">{s.label}</span>
                    <Badge color={s.color as any}>{s.status}</Badge>
                  </div>
                ))}
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {active === 'bookings' && (
        <TableView
          title="All Bookings"
          search={search}
          setSearch={setSearch}
          columns={['Booking ID', 'Customer', 'Service', 'Provider', 'Date', 'Amount', 'Status']}
          tabs={['All', 'Pending', 'Active', 'Completed', 'Cancelled']}
        >
          {sampleBookings.map((b) => {
            const status = bookingStatuses.find(s => s.id === b.status);
            return (
              <tr key={b.id} className="hover:bg-slate-50">
                <td className="p-3 font-mono text-xs text-slate-600">{b.id}</td>
                <td className="p-3 text-sm font-medium">{b.customer}</td>
                <td className="p-3 text-sm">{b.service}</td>
                <td className="p-3 text-sm text-slate-600">{b.provider}</td>
                <td className="p-3 text-sm text-slate-500">{b.date}</td>
                <td className="p-3 text-sm font-semibold">AED {b.amount}</td>
                <td className="p-3"><Badge color={b.status === 'completed' ? 'emerald' : b.status === 'cancelled' ? 'red' : b.status === 'pending' ? 'default' : 'blue'}>{status?.label}</Badge></td>
                <td className="p-3 text-right">
                  <div className="flex gap-1 justify-end">
                    <button className="p-1.5 rounded-lg hover:bg-slate-100"><Eye size={14} /></button>
                    <button className="p-1.5 rounded-lg hover:bg-slate-100"><MoreVertical size={14} /></button>
                  </div>
                </td>
              </tr>
            );
          })}
        </TableView>
      )}

      {active === 'providers' && (
        <TableView title="Providers" search={search} setSearch={setSearch} columns={['ID', 'Business', 'Category', 'City', 'Rating', 'Jobs', 'Earnings', 'Status']} tabs={['All', 'Verified', 'Pending', 'Suspended']}>
          {sampleProviders.map((p) => (
            <tr key={p.id} className="hover:bg-slate-50">
              <td className="p-3 font-mono text-xs">{p.id}</td>
              <td className="p-3"><div className="flex items-center gap-2"><span className="text-lg">{p.avatar}</span><div><div className="text-sm font-semibold">{p.name}</div><div className="text-xs text-slate-500">{p.provider}</div></div></div></td>
              <td className="p-3 text-sm">{p.category}</td>
              <td className="p-3 text-sm">{p.city}</td>
              <td className="p-3 text-sm">⭐ {p.rating}</td>
              <td className="p-3 text-sm">{p.jobs}</td>
              <td className="p-3 text-sm font-semibold">AED {p.earned.toLocaleString()}</td>
              <td className="p-3"><Badge color={p.status === 'verified' ? 'emerald' : p.status === 'pending' ? 'amber' : 'red'}>{p.status}</Badge></td>
              <td className="p-3 text-right">
                <div className="flex gap-1 justify-end">
                  {p.status === 'pending' && <button className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200" title="Approve"><CheckCircle2 size={14} /></button>}
                  {p.status === 'verified' && <button className="p-1.5 rounded-lg bg-red-100 text-red-700 hover:bg-red-200" title="Suspend"><XCircle size={14} /></button>}
                </div>
              </td>
            </tr>
          ))}
        </TableView>
      )}

      {active === 'customers' && (
        <TableView title="Customers" search={search} setSearch={setSearch} columns={['ID', 'Name', 'Email', 'City', 'Bookings', 'Spent']} tabs={['All', 'Active', 'VIP']}>
          {sampleCustomers.map((c) => (
            <tr key={c.id} className="hover:bg-slate-50">
              <td className="p-3 font-mono text-xs">{c.id}</td>
              <td className="p-3"><div className="flex items-center gap-2"><span className="text-lg">{c.avatar}</span><span className="text-sm font-semibold">{c.name}</span></div></td>
              <td className="p-3 text-sm text-slate-600">{c.email}</td>
              <td className="p-3 text-sm">{c.city}</td>
              <td className="p-3 text-sm">{c.totalBookings}</td>
              <td className="p-3 text-sm font-semibold">AED {c.totalSpent.toLocaleString()}</td>
              <td className="p-3 text-right"><button className="p-1.5 rounded-lg hover:bg-slate-100"><Eye size={14} /></button></td>
            </tr>
          ))}
        </TableView>
      )}

      {active === 'services' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {services.map((s) => (
            <Card key={s.id}>
              <CardBody>
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center text-2xl mb-3`}>{s.icon}</div>
                <h3 className="font-bold mb-1">{s.name}</h3>
                <p className="text-xs text-slate-500 mb-4">{s.subcategories.length} sub-services</p>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost">Edit</Button>
                  <Button size="sm" variant="outline">Manage</Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {active === 'complaints' && (
        <Card>
          <CardHeader title="Complaints" subtitle="12 active complaints" action={<div className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-sm" /></div>} />
          <CardBody>
            <div className="space-y-3">
              {supportTickets.map((t) => (
                <div key={t.id} className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-mono text-xs text-slate-400">{t.id}</span>
                        <Badge color={t.priority === 'urgent' ? 'red' : t.priority === 'high' ? 'amber' : t.priority === 'medium' ? 'blue' : 'default'}>{t.priority}</Badge>
                        <Badge color={t.status === 'resolved' ? 'emerald' : t.status === 'escalated' ? 'red' : t.status === 'in_progress' ? 'blue' : 'amber'}>{t.status.replace('_', ' ')}</Badge>
                      </div>
                      <div className="font-semibold">{t.subject}</div>
                      <div className="text-sm text-slate-500">{t.customer} · {t.category} · {t.date}</div>
                    </div>
                    <Button size="sm">Resolve</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'payments' && (
        <Card>
          <CardHeader title="Payment Transactions" />
          <CardBody className="p-0">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
                <tr><th className="p-3 text-left">TX ID</th><th className="p-3 text-left">Type</th><th className="p-3 text-left">Party</th><th className="p-3 text-left">Amount</th><th className="p-3 text-left">Status</th><th className="p-3 text-left">Date</th></tr>
              </thead>
              <tbody>
                {recentTransactions.map((t) => (
                  <tr key={t.id} className="border-t border-slate-100">
                    <td className="p-3 font-mono text-xs">{t.id}</td><td className="p-3">{t.type}</td><td className="p-3">{t.customer}</td>
                    <td className="p-3 font-semibold">AED {t.amount}</td>
                    <td className="p-3"><Badge color={t.status === 'completed' ? 'emerald' : 'amber'}>{t.status}</Badge></td>
                    <td className="p-3 text-slate-500">{t.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      )}

      {active === 'marketing' && <MarketingView />}
      {active === 'analytics' && <AnalyticsView />}
    </PortalLayout>
  );
}

function TableView({ title, search, setSearch, columns, tabs, children }: any) {
  return (
    <Card>
      <div className="p-5 border-b border-slate-100">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <h3 className="text-lg font-bold">{title}</h3>
          <div className="flex items-center gap-2">
            <div className="relative flex-1 lg:w-64">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-slate-900" />
            </div>
            <Button size="sm" variant="outline">Export</Button>
          </div>
        </div>
        {tabs && <div className="flex gap-2 mt-4 overflow-x-auto">
          {tabs.map((t: string, i: number) => (
            <button key={t} className={`flex-shrink-0 px-4 py-1.5 rounded-lg text-xs font-semibold ${i === 0 ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'}`}>{t}</button>
          ))}
        </div>}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
            <tr>{columns.map((c: string) => <th key={c} className="p-3 text-left font-semibold">{c}</th>)}<th className="p-3 text-right w-20">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">{children}</tbody>
        </table>
      </div>
    </Card>
  );
}

function MarketingView() {
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader title="Active Promo Codes" action={<Button size="sm">+ New Code</Button>} />
        <CardBody className="space-y-3">
          {[
            { code: 'WELCOME50', desc: 'AED 50 off first booking', uses: 1240, status: 'active' },
            { code: 'CLEAN20', desc: '20% off cleaning', uses: 890, status: 'active' },
            { code: 'SUMMER100', desc: 'AED 100 off above AED 500', uses: 420, status: 'active' },
          ].map((p) => (
            <div key={p.code} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
              <div className="px-3 py-1.5 rounded-lg bg-slate-900 text-white font-mono text-xs font-bold">{p.code}</div>
              <div className="flex-1"><div className="text-sm font-medium">{p.desc}</div><div className="text-xs text-slate-500">{p.uses.toLocaleString()} uses</div></div>
              <Badge color="emerald">{p.status}</Badge>
            </div>
          ))}
        </CardBody>
      </Card>
      <Card>
        <CardHeader title="Campaigns" />
        <CardBody className="space-y-3">
          {[
            { name: 'WhatsApp Blast · Weekend', sent: 12400, opened: 68, date: '2 days ago' },
            { name: 'Email · New Provider Offers', sent: 48200, opened: 42, date: '5 days ago' },
            { name: 'Push · AC Season Special', sent: 89000, opened: 14, date: '1 week ago' },
          ].map((c) => (
            <div key={c.name} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
              <div className="flex-1"><div className="text-sm font-medium">{c.name}</div><div className="text-xs text-slate-500">{c.sent.toLocaleString()} sent · {c.opened}% open · {c.date}</div></div>
              <div className="w-20 h-2 bg-slate-200 rounded-full overflow-hidden"><div className="h-full bg-violet-500 rounded-full" style={{ width: `${c.opened}%` }} /></div>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}

function AnalyticsView() {
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {[
        { title: 'Customer Analytics', data: [{ label: 'New Users', value: '2,480', change: '+18%' }, { label: 'Retention', value: '72%', change: '+4%' }, { label: 'Churn', value: '3.2%', change: '-0.8%' }] },
        { title: 'Provider Analytics', data: [{ label: 'New Signups', value: '142', change: '+22%' }, { label: 'Verification Rate', value: '89%', change: '+5%' }, { label: 'Avg. Rating', value: '4.82', change: '+0.1' }] },
        { title: 'Operational', data: [{ label: 'Response Time', value: '4.2 min', change: '-12%' }, { label: 'Completion Rate', value: '96.4%', change: '+1.2%' }, { label: 'Dispute Rate', value: '1.8%', change: '-0.3%' }] },
        { title: 'Financial', data: [{ label: 'GMV', value: 'AED 1.24M', change: '+22%' }, { label: 'Take Rate', value: '15%', change: '+0.5%' }, { label: 'Net Revenue', value: 'AED 186K', change: '+24%' }] },
      ].map((section) => (
        <Card key={section.title}>
          <CardHeader title={section.title} />
          <CardBody className="space-y-4">
            {section.data.map((m) => (
              <div key={m.label} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                <div className="text-sm font-medium">{m.label}</div>
                <div className="text-right"><div className="text-lg font-bold">{m.value}</div><div className="text-xs text-emerald-600 font-semibold">{m.change}</div></div>
              </div>
            ))}
          </CardBody>
        </Card>
      ))}
    </div>
  );
}
