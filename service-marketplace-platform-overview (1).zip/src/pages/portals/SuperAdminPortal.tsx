import { useState } from 'react';
import PortalLayout from '../../components/PortalLayout';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { DollarSign, Shield, Key, Database, Settings, MapPin, FileText, ToggleLeft } from 'lucide-react';

export default function SuperAdminPortal() {
  const [active, setActive] = useState('dashboard');

  return (
    <PortalLayout role="superadmin" active={active} onChange={setActive}>
      {active === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Platform Revenue', value: 'AED 186K', sub: 'This month', icon: <DollarSign />, color: 'from-amber-500 to-orange-600' },
              { label: 'Total GMV', value: 'AED 1.24M', sub: 'Lifetime', icon: <DollarSign />, color: 'from-emerald-500 to-teal-600' },
              { label: 'Active Roles', value: '8', sub: 'Across 5 portals', icon: <Shield />, color: 'from-violet-500 to-purple-600' },
              { label: 'API Requests', value: '2.4M', sub: 'Last 24hrs', icon: <Database />, color: 'from-blue-500 to-indigo-600' },
            ].map((k) => (
              <div key={k.label} className="bg-white rounded-2xl p-5 border border-slate-200">
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${k.color} flex items-center justify-center text-white mb-3`}>{k.icon}</div>
                <div className="text-xs text-slate-500">{k.label}</div>
                <div className="text-2xl font-black text-slate-900 mt-1">{k.value}</div>
                <div className="text-xs text-slate-400 mt-0.5">{k.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader title="System Health" />
              <CardBody className="space-y-2">
                {[
                  { name: 'PostgreSQL', status: 'Healthy', latency: '2ms' },
                  { name: 'Redis Cache', status: 'Healthy', latency: '1ms' },
                  { name: 'Stripe API', status: 'Healthy', latency: '142ms' },
                  { name: 'Firebase FCM', status: 'Healthy', latency: '89ms' },
                  { name: 'WhatsApp Cloud API', status: 'Degraded', latency: '412ms' },
                  { name: 'Google Maps API', status: 'Healthy', latency: '67ms' },
                  { name: 'Supabase Storage', status: 'Healthy', latency: '23ms' },
                ].map((s) => (
                  <div key={s.name} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50">
                    <span className="text-sm font-medium">{s.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-400">{s.latency}</span>
                      <Badge color={s.status === 'Healthy' ? 'emerald' : 'amber'}>{s.status}</Badge>
                    </div>
                  </div>
                ))}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Feature Flags" />
              <CardBody className="space-y-3">
                {[
                  { name: 'Wallet System', enabled: true, desc: 'Customer wallet & cashback' },
                  { name: 'Apple Pay', enabled: true, desc: 'Apple Pay integration' },
                  { name: 'Recurring Bookings', enabled: false, desc: 'Schedule recurring services' },
                  { name: 'Emergency Services', enabled: true, desc: '24/7 emergency category' },
                  { name: 'Provider Chat', enabled: true, desc: 'In-app provider messaging' },
                  { name: 'AI Auto-Match', enabled: false, desc: 'Auto-match providers to jobs' },
                ].map((f) => (
                  <div key={f.name} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                    <ToggleLeft size={20} className={f.enabled ? 'text-emerald-600' : 'text-slate-300'} />
                    <div className="flex-1">
                      <div className="text-sm font-semibold">{f.name}</div>
                      <div className="text-xs text-slate-500">{f.desc}</div>
                    </div>
                    <div className={`w-10 h-6 rounded-full p-0.5 transition-colors ${f.enabled ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                      <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${f.enabled ? 'translate-x-4' : ''}`} />
                    </div>
                  </div>
                ))}
              </CardBody>
            </Card>
          </div>

          <Card>
            <CardHeader title="Recent Audit Logs" subtitle="Last 24 hours" />
            <CardBody>
              <div className="space-y-2">
                {[
                  { actor: 'dr.aisha@wasta.ae', action: 'Updated commission structure for Cleaning', time: '2 min ago', type: 'config' },
                  { actor: 'omar.k@wasta.ae', action: 'Approved provider P-006 (Swift Movers)', time: '18 min ago', type: 'approval' },
                  { actor: 'system', action: 'Auto-escalated ticket TKT-9005 (urgent payment issue)', time: '34 min ago', type: 'system' },
                  { actor: 'dr.aisha@wasta.ae', action: 'Disabled provider P-008 (suspended)', time: '1 hr ago', type: 'security' },
                  { actor: 'system', action: 'Feature flag "Apple Pay" toggled ON', time: '2 hrs ago', type: 'config' },
                ].map((log, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-slate-200">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${log.type === 'config' ? 'bg-violet-100 text-violet-600' : log.type === 'security' ? 'bg-red-100 text-red-600' : log.type === 'approval' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600'}`}>
                      <FileText size={14} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{log.action}</div>
                      <div className="text-xs text-slate-500">{log.actor} · {log.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'commission' && (
        <div className="space-y-6">
          <Card>
            <CardHeader title="Commission Structure" subtitle="Platform fees per service category" action={<Button size="sm">+ Add Tier</Button>} />
            <CardBody>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs text-slate-500 uppercase">
                    <tr>
                      <th className="p-3 text-left">Category</th>
                      <th className="p-3 text-left">Base Commission</th>
                      <th className="p-3 text-left">VAT on Commission</th>
                      <th className="p-3 text-left">Processing Fee</th>
                      <th className="p-3 text-left">Minimum Fee</th>
                      <th className="p-3 text-left">Effective</th>
                      <th className="p-3"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { cat: 'Cleaning', base: 15, vat: 5, processing: 2.5, min: 10 },
                      { cat: 'Electrical', base: 12, vat: 5, processing: 2.5, min: 15 },
                      { cat: 'Plumbing', base: 12, vat: 5, processing: 2.5, min: 15 },
                      { cat: 'AC Services', base: 14, vat: 5, processing: 2.5, min: 12 },
                      { cat: 'Beauty', base: 18, vat: 5, processing: 2.5, min: 12 },
                      { cat: 'Moving', base: 10, vat: 5, processing: 2.5, min: 20 },
                    ].map((c) => (
                      <tr key={c.cat} className="border-t border-slate-100 hover:bg-slate-50">
                        <td className="p-3 font-semibold">{c.cat}</td>
                        <td className="p-3">{c.base}%</td>
                        <td className="p-3">{c.vat}%</td>
                        <td className="p-3">{c.processing}%</td>
                        <td className="p-3">AED {c.min}</td>
                        <td className="p-3"><Badge color="emerald">{(c.base + c.vat + c.processing).toFixed(1)}%</Badge></td>
                        <td className="p-3 text-right"><button className="p-1.5 rounded-lg hover:bg-slate-100"><Settings size={14} /></button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader title="Payout Schedule" />
              <CardBody className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-50"><div className="text-xs text-slate-500">Standard Payout</div><div className="font-bold">Weekly (Sunday)</div></div>
                <div className="p-3 rounded-xl bg-emerald-50"><div className="text-xs text-emerald-700">Instant Payout</div><div className="font-bold text-emerald-900">1% fee · Available</div></div>
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Tax Configuration" />
              <CardBody className="space-y-3">
                <div className="flex justify-between p-2"><span>VAT Rate</span><span className="font-bold">5%</span></div>
                <div className="flex justify-between p-2"><span>Platform Country</span><span className="font-bold">UAE</span></div>
                <div className="flex justify-between p-2"><span>Currency</span><span className="font-bold">AED</span></div>
              </CardBody>
            </Card>
            <Card>
              <CardHeader title="Revenue Split" />
              <CardBody className="space-y-2">
                {[
                  { label: 'Provider', value: 85, color: 'bg-emerald-500' },
                  { label: 'Platform', value: 12.5, color: 'bg-violet-500' },
                  { label: 'Processing', value: 2.5, color: 'bg-blue-500' },
                ].map((s) => (
                  <div key={s.label}>
                    <div className="flex justify-between text-xs mb-1"><span>{s.label}</span><span className="font-bold">{s.value}%</span></div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden"><div className={`h-full ${s.color} rounded-full`} style={{ width: `${s.value}%` }} /></div>
                  </div>
                ))}
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {active === 'roles' && (
        <div className="space-y-6">
          <Card>
            <CardHeader title="Roles & Permissions" action={<Button size="sm">+ Create Role</Button>} />
            <CardBody>
              <div className="space-y-3">
                {[
                  { role: 'Super Admin', users: 3, perms: 48, color: 'amber' },
                  { role: 'Admin', users: 24, perms: 32, color: 'violet' },
                  { role: 'Support Lead', users: 8, perms: 18, color: 'cyan' },
                  { role: 'Support Agent', users: 42, perms: 12, color: 'blue' },
                  { role: 'Finance', users: 6, perms: 15, color: 'emerald' },
                  { role: 'Moderator', users: 12, perms: 10, color: 'rose' },
                ].map((r) => (
                  <div key={r.role} className="flex items-center gap-4 p-4 rounded-xl border border-slate-200">
                    <div className={`w-11 h-11 rounded-xl bg-${r.color}-100 flex items-center justify-center`}>
                      <Shield size={20} className={`text-${r.color}-600`} />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold">{r.role}</div>
                      <div className="text-xs text-slate-500">{r.users} users · {r.perms} permissions</div>
                    </div>
                    <Button size="sm" variant="outline">Edit Permissions</Button>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Permission Matrix" />
            <CardBody>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="text-slate-500 uppercase">
                    <tr>
                      <th className="p-2 text-left">Permission</th>
                      <th className="p-2 text-center">Super</th>
                      <th className="p-2 text-center">Admin</th>
                      <th className="p-2 text-center">Support</th>
                      <th className="p-2 text-center">Finance</th>
                      <th className="p-2 text-center">Mod</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['Manage Roles', 1, 0, 0, 0, 0],
                      ['Manage Commission', 1, 0, 0, 0, 0],
                      ['Approve Providers', 1, 1, 0, 0, 0],
                      ['Issue Refunds', 1, 1, 1, 1, 0],
                      ['View Analytics', 1, 1, 0, 1, 0],
                      ['Moderate Reviews', 1, 1, 0, 0, 1],
                      ['Manage Tickets', 1, 1, 1, 0, 0],
                      ['Broadcast Messages', 1, 1, 0, 0, 0],
                    ].map((row) => (
                      <tr key={row[0] as string} className="border-t border-slate-100">
                        <td className="p-2 font-medium">{row[0]}</td>
                        {row.slice(1).map((v, i) => (
                          <td key={i} className="p-2 text-center">
                            {v ? <span className="text-emerald-600">●</span> : <span className="text-slate-300">○</span>}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'finance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total Revenue', value: 'AED 186K', sub: 'This month', trend: '+24%' },
              { label: 'Provider Payouts', value: 'AED 998K', sub: 'Pending: AED 195K', trend: '+20%' },
              { label: 'Refunds Issued', value: 'AED 12.4K', sub: 'This month', trend: '-8%' },
              { label: 'VAT Collected', value: 'AED 59.2K', sub: 'Q1 2025', trend: '+22%' },
            ].map((f) => (
              <Card key={f.label}>
                <CardBody>
                  <div className="text-xs text-slate-500 mb-1">{f.label}</div>
                  <div className="text-2xl font-black">{f.value}</div>
                  <div className="text-xs text-slate-400 mt-1">{f.sub}</div>
                  <div className="text-xs text-emerald-600 font-semibold mt-2">{f.trend}</div>
                </CardBody>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader title="Financial Reports" action={<Button size="sm">Export CSV</Button>} />
            <CardBody>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {['Monthly Revenue', 'Provider Payouts', 'Commission Report', 'Tax Summary', 'Refund Report', 'Outstanding Invoices', 'Provider Tax Forms', 'Stripe Reconciliation'].map((r) => (
                  <button key={r} className="p-4 rounded-xl border border-slate-200 text-left hover:border-slate-300 hover:shadow-sm transition-all">
                    <FileText size={20} className="text-amber-600 mb-2" />
                    <div className="text-sm font-semibold">{r}</div>
                  </button>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'regions' && (
        <Card>
          <CardHeader title="Regions & Markets" subtitle="Configure marketplace settings per region" action={<Button size="sm">+ Add Region</Button>} />
          <CardBody>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { name: 'Dubai', providers: 1847, customers: '98K', status: 'active', flag: '🇦🇪' },
                { name: 'Abu Dhabi', providers: 524, customers: '28K', status: 'active', flag: '🇦🇪' },
                { name: 'Sharjah', providers: 289, customers: '12K', status: 'active', flag: '🇦🇪' },
                { name: 'Ajman', providers: 98, customers: '3.2K', status: 'active', flag: '🇦🇪' },
                { name: 'Ras Al Khaimah', providers: 54, customers: '1.1K', status: 'active', flag: '🇦🇪' },
                { name: 'Riyadh (Beta)', providers: 0, customers: '0', status: 'coming_soon', flag: '🇸🇦' },
              ].map((r) => (
                <div key={r.name} className="flex items-center gap-3 p-4 rounded-xl border border-slate-200">
                  <span className="text-3xl">{r.flag}</span>
                  <div className="flex-1">
                    <div className="font-semibold flex items-center gap-2">{r.name}{r.status === 'coming_soon' && <Badge color="amber">Soon</Badge>}</div>
                    <div className="text-xs text-slate-500">{r.providers} providers · {r.customers} customers</div>
                  </div>
                  <MapPin size={18} className="text-slate-400" />
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {(active === 'api' || active === 'audit' || active === 'config' || active === 'feature-flags') && (
        <Card>
          <CardHeader title={active.charAt(0).toUpperCase() + active.slice(1).replace('-', ' ')} />
          <CardBody>
            <div className="text-center py-12 text-slate-400">
              <Key size={40} className="mx-auto mb-3 opacity-50" />
              <p>Enterprise controls configured under this module. Full CRUD interfaces available in production deployment.</p>
            </div>
          </CardBody>
        </Card>
      )}
    </PortalLayout>
  );
}
