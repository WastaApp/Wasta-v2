import { useState } from 'react';
import PortalLayout from '../../components/PortalLayout';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { supportTickets } from '../../data/mockData';
import { MessageSquare, AlertTriangle, Clock, TrendingUp, CheckCircle2, Send, User, Phone } from 'lucide-react';

export default function SupportPortal() {
  const [active, setActive] = useState('dashboard');
  const [selectedTicket, setSelectedTicket] = useState<string | null>(null);

  const openCount = supportTickets.filter(t => t.status === 'open' || t.status === 'in_progress').length;
  const escalatedCount = supportTickets.filter(t => t.status === 'escalated').length;

  return (
    <PortalLayout role="support" active={active} onChange={(v) => { setActive(v); setSelectedTicket(null); }}>
      {active === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Open Tickets', value: openCount, sub: 'Requires action', icon: <MessageSquare />, color: 'from-cyan-500 to-blue-600' },
              { label: 'Escalated', value: escalatedCount, sub: 'Priority', icon: <AlertTriangle />, color: 'from-red-500 to-rose-600' },
              { label: 'Avg Response', value: '2.8 min', sub: 'This week', icon: <Clock />, color: 'from-amber-500 to-orange-500' },
              { label: 'CSAT Score', value: '4.7★', sub: 'Last 30 days', icon: <TrendingUp />, color: 'from-emerald-500 to-teal-600' },
            ].map((k) => (
              <div key={k.label} className="bg-white rounded-2xl p-5 border border-slate-200">
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${k.color} flex items-center justify-center text-white mb-3`}>{k.icon}</div>
                <div className="text-xs text-slate-500 mb-1">{k.label}</div>
                <div className="text-2xl font-black text-slate-900">{k.value}</div>
                <div className="text-xs text-slate-400 mt-1">{k.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader title="Queue Overview" action={<Button size="sm" onClick={() => setActive('tickets')}>View All</Button>} />
              <CardBody className="space-y-2">
                {supportTickets.map((t) => (
                  <button key={t.id} onClick={() => setSelectedTicket(t.id)} className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:border-cyan-300 hover:bg-cyan-50/30 transition-all text-left">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      t.priority === 'urgent' ? 'bg-red-100 text-red-600' :
                      t.priority === 'high' ? 'bg-amber-100 text-amber-600' :
                      t.priority === 'medium' ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <AlertTriangle size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold truncate">{t.subject}</span>
                        <span className="text-xs font-mono text-slate-400">{t.id}</span>
                      </div>
                      <div className="text-xs text-slate-500">{t.customer} · {t.category}</div>
                    </div>
                    <Badge color={t.status === 'resolved' ? 'emerald' : t.status === 'escalated' ? 'red' : t.status === 'in_progress' ? 'blue' : 'amber'}>
                      {t.status.replace('_', ' ')}
                    </Badge>
                  </button>
                ))}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="My Performance Today" />
              <CardBody className="space-y-4">
                {[
                  { label: 'Resolved', value: 14, target: 20, color: 'emerald' },
                  { label: 'Avg Handle Time', value: '6.2 min', target: '< 10 min', color: 'blue' },
                  { label: 'CSAT Today', value: '4.9★', target: '> 4.5★', color: 'amber' },
                  { label: 'First Contact Resolution', value: '89%', target: '> 80%', color: 'violet' },
                ].map((m) => (
                  <div key={m.label} className="p-3 rounded-xl bg-slate-50">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold text-slate-600">{m.label}</span>
                      <span className="text-xs text-slate-400">Target: {m.target}</span>
                    </div>
                    <div className="text-xl font-black">{m.value}</div>
                  </div>
                ))}
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {(active === 'tickets' || selectedTicket) && (
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader title="Ticket Queue" action={<span className="text-xs font-semibold text-cyan-600">{supportTickets.length} total</span>} />
            <CardBody className="p-0">
              <div className="space-y-1">
                {supportTickets.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTicket(t.id)}
                    className={`w-full text-left p-4 border-l-4 transition-colors ${
                      selectedTicket === t.id ? 'bg-cyan-50 border-cyan-500' : 'border-transparent hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-mono text-slate-400">{t.id}</span>
                      <Badge color={t.priority === 'urgent' ? 'red' : t.priority === 'high' ? 'amber' : t.priority === 'medium' ? 'blue' : 'default'}>{t.priority}</Badge>
                    </div>
                    <div className="text-sm font-semibold line-clamp-1">{t.subject}</div>
                    <div className="text-xs text-slate-500 mt-1">{t.customer} · {t.date}</div>
                  </button>
                ))}
              </div>
            </CardBody>
          </Card>

          <div className="lg:col-span-2 space-y-4">
            {selectedTicket ? (
              <TicketDetail id={selectedTicket} />
            ) : (
              <Card>
                <CardBody className="text-center py-12 text-slate-400">
                  <MessageSquare size={40} className="mx-auto mb-3 opacity-50" />
                  <p>Select a ticket to view details</p>
                </CardBody>
              </Card>
            )}
          </div>
        </div>
      )}

      {active === 'chats' && (
        <Card>
          <CardHeader title="Live Chats" subtitle="5 active conversations" />
          <CardBody className="p-0">
            <div className="divide-y divide-slate-100">
              {[
                { name: 'Sarah Al-Maktoum', msg: 'Hi, I need help with my booking WST-20250008', time: '2 min ago', avatar: '👩', online: true },
                { name: 'James O\'Connor', msg: 'When will my refund be processed?', time: '5 min ago', avatar: '🧑', online: true },
                { name: 'Mohammed Al-Rashid', msg: 'I was double charged for my service', time: '12 min ago', avatar: '👨', online: true },
                { name: 'Priya Nair', msg: 'Can I reschedule my appointment?', time: '25 min ago', avatar: '👩‍💼', online: false },
                { name: 'Fatima Hassan', msg: 'Provider hasn\'t arrived yet', time: '38 min ago', avatar: '👩‍🦱', online: false },
              ].map((c, i) => (
                <div key={i} className="flex items-center gap-4 p-4 hover:bg-slate-50 cursor-pointer">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-xl">{c.avatar}</div>
                    {c.online && <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{c.name}</span>
                      <span className="text-xs text-slate-400">{c.time}</span>
                    </div>
                    <div className="text-sm text-slate-500 truncate">{c.msg}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'refunds' && (
        <Card>
          <CardHeader title="Refund Requests" subtitle="6 pending review" />
          <CardBody>
            <div className="space-y-3">
              {[
                { id: 'WST-20250008', customer: 'James O\'Connor', amount: 110, reason: 'Provider didn\'t show up', date: '2 hours ago', status: 'pending' },
                { id: 'WST-20249982', customer: 'Ahmed Bin Ali', amount: 300, reason: 'Poor service quality', date: '5 hours ago', status: 'pending' },
                { id: 'WST-20249965', customer: 'Fatima Hassan', amount: 95, reason: 'Cancelled within window', date: '1 day ago', status: 'pending' },
              ].map((r) => (
                <div key={r.id} className="p-4 rounded-xl border border-slate-200">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <div className="font-mono text-xs text-slate-400">{r.id}</div>
                      <div className="font-semibold">{r.customer}</div>
                      <div className="text-sm text-slate-500">{r.reason}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold">AED {r.amount}</div>
                      <div className="text-xs text-slate-400">{r.date}</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm">Approve Refund</Button>
                    <Button size="sm" variant="outline">Decline</Button>
                    <Button size="sm" variant="ghost">Contact Customer</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {active === 'escalations' && (
        <Card>
          <CardHeader title="Escalated Tickets" subtitle="3 tickets requiring senior attention" />
          <CardBody className="space-y-3">
            {supportTickets.filter(t => t.status === 'escalated').map((t) => (
              <div key={t.id} className="p-4 rounded-xl border-2 border-red-200 bg-red-50/50">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle size={18} className="text-red-600" />
                  <span className="font-mono text-xs text-red-700">{t.id}</span>
                  <Badge color="red">{t.priority}</Badge>
                </div>
                <div className="font-semibold mb-1">{t.subject}</div>
                <div className="text-sm text-slate-600 mb-3">{t.customer} · Escalated due to repeated contact</div>
                <Button size="sm">Take Action</Button>
              </div>
            ))}
          </CardBody>
        </Card>
      )}

      {active === 'performance' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader title="This Week's Performance" />
            <CardBody className="space-y-4">
              {[
                { metric: 'Tickets Resolved', value: 87, target: 100 },
                { metric: 'Avg Response Time', value: '3.2 min', target: '< 5 min' },
                { metric: 'Customer Satisfaction', value: '4.8/5', target: '> 4.5' },
                { metric: 'First Contact Resolution', value: '91%', target: '> 85%' },
              ].map((m) => (
                <div key={m.metric} className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                  <span className="text-sm font-medium">{m.metric}</span>
                  <div className="text-right"><div className="font-bold text-lg">{m.value}</div><div className="text-xs text-slate-500">Target: {m.target}</div></div>
                </div>
              ))}
            </CardBody>
          </Card>
          <Card>
            <CardHeader title="Recent Achievements" />
            <CardBody className="space-y-3">
              {[
                { icon: '🏆', title: 'Top Agent of the Week', desc: 'Highest CSAT score (4.98)' },
                { icon: '⚡', title: 'Speed Demon', desc: 'Resolved 25 tickets under 3 minutes' },
                { icon: '💎', title: '100% Resolution', desc: 'Zero escalations this month' },
              ].map((a, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200">
                  <span className="text-3xl">{a.icon}</span>
                  <div><div className="font-semibold">{a.title}</div><div className="text-xs text-slate-500">{a.desc}</div></div>
                </div>
              ))}
            </CardBody>
          </Card>
        </div>
      )}

      {active === 'knowledge' && (
        <Card>
          <CardHeader title="Knowledge Base" subtitle="Quick responses and articles" />
          <CardBody>
            <div className="grid sm:grid-cols-2 gap-3">
              {[
                'Refund Policy', 'How to Cancel Booking', 'Provider Verification Process',
                'Payment Methods', 'Loyalty Program FAQ', 'Service Guarantee',
                'What if provider doesn\'t arrive?', 'Rescheduling Policy',
              ].map((a) => (
                <button key={a} className="p-4 rounded-xl border border-slate-200 text-left hover:border-cyan-300 hover:shadow-sm transition-all">
                  <span className="text-sm font-semibold">{a}</span>
                </button>
              ))}
            </div>
          </CardBody>
        </Card>
      )}
    </PortalLayout>
  );
}

function TicketDetail({ id }: { id: string }) {
  const ticket = supportTickets.find(t => t.id === id);
  if (!ticket) return null;

  return (
    <>
      <Card>
        <CardBody className="p-6">
          <div className="flex items-start justify-between gap-4 mb-5">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-mono text-xs text-slate-400">{ticket.id}</span>
                <Badge color={ticket.priority === 'urgent' ? 'red' : ticket.priority === 'high' ? 'amber' : 'blue'}>{ticket.priority}</Badge>
                <Badge color={ticket.status === 'resolved' ? 'emerald' : ticket.status === 'escalated' ? 'red' : 'blue'}>{ticket.status.replace('_', ' ')}</Badge>
              </div>
              <h3 className="text-xl font-bold">{ticket.subject}</h3>
              <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
                <span className="flex items-center gap-1"><User size={14} />{ticket.customer}</span>
                <span className="flex items-center gap-1"><Clock size={14} />{ticket.date}</span>
                <span className="flex items-center gap-1"><Phone size={14} />+971 50 123 4567</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline">Escalate</Button>
              <Button size="sm"><CheckCircle2 size={14} /> Resolve</Button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-50 border-l-4 border-slate-300">
              <div className="text-xs font-semibold text-slate-500 mb-1">{ticket.customer} · {ticket.date}</div>
              <p className="text-sm">Hi there, I need help with this issue. The provider arrived late and the service quality wasn't as expected. I'd like to discuss possible resolution options. Thank you!</p>
            </div>
            <div className="p-4 rounded-xl bg-cyan-50 border-l-4 border-cyan-500">
              <div className="text-xs font-semibold text-cyan-700 mb-1">Layla Rahman · Just now</div>
              <p className="text-sm">Hello! I'm sorry to hear about your experience. Let me review the booking details and get this resolved for you right away. I can offer a partial refund or arrange a complimentary re-service. Which would you prefer?</p>
            </div>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="flex gap-2 mb-3">
            <input type="text" placeholder="Type your reply..." className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-cyan-500 text-sm" />
            <Button><Send size={14} /> Send</Button>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-xs font-medium hover:bg-slate-200">Offer Partial Refund</button>
            <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-xs font-medium hover:bg-slate-200">Schedule Re-service</button>
            <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-xs font-medium hover:bg-slate-200">Full Refund</button>
            <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-xs font-medium hover:bg-slate-200">Apologize</button>
          </div>
        </CardBody>
      </Card>
    </>
  );
}
