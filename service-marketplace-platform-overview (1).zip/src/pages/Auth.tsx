import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Phone, ArrowRight, Lock, ShieldCheck } from 'lucide-react';

export default function Auth() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const role = params.get('role') || 'customer';
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length >= 9) setStep('otp');
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/portal/${role}`);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-slate-900 via-indigo-950 to-violet-950 p-12 items-center relative overflow-hidden">
        <div className="absolute inset-0 mesh-gradient opacity-40" />
        <div className="relative max-w-md">
          <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center mb-8">
            <span className="text-slate-900 font-black text-xl">W</span>
          </div>
          <h2 className="text-4xl font-black text-white leading-tight mb-4">
            Welcome to<br />WASTA
          </h2>
          <p className="text-slate-300 text-lg leading-relaxed mb-8">
            The UAE's #1 marketplace for home services. Join 142,000+ customers and 2,800+ verified professionals.
          </p>
          <div className="space-y-3">
            {[
              'Verified & background-checked professionals',
              'Secure payments with escrow protection',
              'Live GPS tracking of your service pro',
              '24/7 support in Arabic & English',
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-3 text-slate-300 text-sm">
                <ShieldCheck size={18} className="text-emerald-400 flex-shrink-0" />
                {feature}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right side */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="mb-8">
            <div className="lg:hidden w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center mb-6">
              <span className="text-white font-black text-xl">W</span>
            </div>
            <h1 className="text-3xl font-black text-slate-900 mb-2">
              {step === 'phone' ? 'Sign in to WASTA' : 'Enter verification code'}
            </h1>
            <p className="text-slate-600 text-sm">
              {step === 'phone'
                ? `Accessing ${role === 'customer' ? 'Customer' : role === 'provider' ? 'Provider' : role === 'support' ? 'Support' : 'Admin'} portal.`
                : `We sent a 4-digit code to ${phone}`}
            </p>
          </div>

          {step === 'phone' ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Phone Number</label>
                <div className="relative">
                  <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="50 123 4567"
                    className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-slate-200 focus:border-slate-900 focus:outline-none text-lg"
                    maxLength={9}
                  />
                  <div className="absolute left-12 top-1/2 -translate-y-1/2 text-slate-400 text-sm pointer-events-none">+971</div>
                  <div className="absolute left-20 top-1/2 -translate-y-1/2 w-px h-5 bg-slate-200 pointer-events-none" />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
              >
                Send Code <ArrowRight size={18} />
              </button>

              <div className="text-center text-xs text-slate-500">
                By continuing, you agree to our Terms of Service & Privacy Policy.
              </div>
            </form>
          ) : (
            <form onSubmit={handleVerify} className="space-y-5">
              <div className="flex justify-center gap-3">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => {
                      const newOtp = [...otp];
                      newOtp[i] = e.target.value.replace(/[^0-9]/g, '');
                      setOtp(newOtp);
                      if (e.target.value && i < 3) {
                        const next = document.getElementById(`otp-${i + 1}`);
                        next?.focus();
                      }
                    }}
                    id={`otp-${i}`}
                    className="w-16 h-16 text-center text-2xl font-black rounded-2xl border-2 border-slate-200 focus:border-slate-900 focus:outline-none"
                  />
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-slate-900 text-white font-semibold hover:bg-slate-800 flex items-center justify-center gap-2"
              >
                <Lock size={18} /> Verify & Continue
              </button>

              <button
                type="button"
                onClick={() => setStep('phone')}
                className="w-full text-sm text-slate-600 hover:text-slate-900"
              >
                Change phone number
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </div>
  );
}
