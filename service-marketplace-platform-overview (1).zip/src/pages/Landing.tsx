import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { services } from '../data/mockData';
import { ArrowRight, Star, Shield, Zap, Users, MapPin, CheckCircle2, Smartphone, Clock, Award } from 'lucide-react';

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-white">
        <div className="absolute inset-0 mesh-gradient opacity-30" />
        <div className="relative max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/5 border border-slate-200 text-slate-700 text-sm font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Now serving 7 emirates
                </span>
              </motion.div>

              <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-5xl lg:text-7xl font-black text-slate-900 tracking-tight leading-[1.05] mb-6">
                Home services,<br />
                <span className="bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent">
                  delivered with
                </span><br />
                <span className="relative inline-block">
                  <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">wasṭa</span>
                  <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 200 12" fill="none">
                    <path d="M2 8C60 2 140 2 198 8" stroke="url(#g)" strokeWidth="4" strokeLinecap="round" />
                    <defs><linearGradient id="g" x1="0" x2="200"><stop stopColor="#6366f1" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient></defs>
                  </svg>
                </span>
              </motion.h1>

              <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-lg text-slate-600 max-w-lg mb-8 leading-relaxed">
                Book trusted professionals for cleaning, electrical, plumbing, AC, beauty, and 50+ services across the UAE. Verified experts at your door in 60 minutes.
              </motion.p>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="flex flex-col sm:flex-row gap-3 mb-10">
                <button onClick={() => navigate('/auth')} className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl bg-slate-900 text-white font-semibold hover:bg-slate-800 shadow-xl shadow-slate-500/20 transition-all hover:scale-105">
                  <Smartphone size={20} /> Book a Service
                  <ArrowRight size={18} />
                </button>
                <button onClick={() => navigate('/portal/provider')} className="inline-flex items-center gap-2 px-6 py-4 rounded-2xl bg-white border-2 border-slate-200 text-slate-700 font-semibold hover:border-slate-300 transition-all">
                  <Award size={20} /> Become a Provider
                </button>
              </motion.div>

              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="flex items-center gap-6">
                <div className="flex -space-x-3">
                  {['👩', '👨', '🧑', '👩‍🦱', '👳'].map((a, i) => (
                    <div key={i} className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 border-2 border-white flex items-center justify-center text-lg">{a}</div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1 text-amber-500">
                    {Array(5).fill(0).map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                    <span className="text-slate-900 font-bold ml-1 text-sm">4.82</span>
                  </div>
                  <div className="text-xs text-slate-500">from 38,240+ verified reviews</div>
                </div>
              </motion.div>
            </div>

            {/* Phone mockup */}
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3 }} className="hidden lg:flex justify-center">
              <div className="relative">
                <div className="w-[340px] h-[700px] rounded-[50px] bg-slate-900 p-3 shadow-2xl shadow-slate-500/30">
                  <div className="w-full h-full rounded-[40px] bg-gradient-to-b from-slate-50 to-white overflow-hidden relative">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-10" />
                    <div className="pt-10 px-5">
                      <div className="flex items-center justify-between mb-5">
                        <div>
                          <div className="text-xs text-slate-400">Good morning 👋</div>
                          <div className="text-base font-bold text-slate-900">Sarah</div>
                        </div>
                        <div className="w-9 h-9 rounded-full bg-blue-500 flex items-center justify-center text-lg">👩</div>
                      </div>

                      <div className="relative mb-4">
                        <input type="text" placeholder="Search services..." readOnly className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white border border-slate-200 text-xs" />
                        <MapPin size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>

                      <div className="grid grid-cols-4 gap-2 mb-4">
                        {services.slice(0, 8).map((s) => (
                          <div key={s.id} className="flex flex-col items-center gap-1 p-2 rounded-xl hover:bg-slate-100 cursor-pointer">
                            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center text-xl`}>{s.icon}</div>
                            <div className="text-[9px] font-medium text-slate-700 text-center leading-tight">{s.name.split(' ')[0]}</div>
                          </div>
                        ))}
                      </div>

                      <div className="rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 p-4 text-white mb-4">
                        <div className="text-xs font-medium opacity-80 mb-1">Active Booking</div>
                        <div className="text-sm font-bold mb-2">Deep Cleaning · 10:00 AM</div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                          <span className="text-xs opacity-90">Maria is on the way</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-3 flex items-center gap-2 animate-float">
                  <CheckCircle2 size={20} className="text-emerald-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900">Booking Confirmed</div>
                    <div className="text-[10px] text-slate-500">Sparkle Clean Pro</div>
                  </div>
                </div>
                <div className="absolute -bottom-2 -left-6 bg-white rounded-2xl shadow-xl p-3 flex items-center gap-2 animate-float" style={{ animationDelay: '2s' }}>
                  <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">⭐</div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">4.9 Rating</div>
                    <div className="text-[10px] text-slate-500">Verified Pro</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-black text-slate-900 mb-3">Services for every need</h2>
            <p className="text-slate-600 max-w-xl mx-auto">From quick fixes to full projects — 50+ services, 100% satisfaction guaranteed.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {services.map((s, i) => (
              <motion.button
                key={s.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                onClick={() => navigate('/portal/customer')}
                className="group text-left p-6 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform`}>
                  {s.icon}
                </div>
                <div className="font-bold text-slate-900 mb-1">{s.name}</div>
                <div className="text-xs text-slate-500">{s.subcategories.length} sub-services</div>
                <div className="mt-3 text-sm font-semibold text-slate-700 group-hover:text-slate-900 flex items-center gap-1">
                  From AED {Math.min(...s.subcategories.map((x) => x.price))} <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 lg:py-24 bg-slate-50">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl lg:text-4xl font-black text-slate-900 mb-3">Book in 3 easy steps</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <Smartphone size={28} />, title: 'Choose your service', desc: 'Browse 50+ services, pick your preferred date and time.' },
              { icon: <Shield size={28} />, title: 'Get matched instantly', desc: 'Verified professional arrives at your doorstep within 60 minutes.' },
              { icon: <Zap size={28} />, title: 'Pay after completion', desc: 'Secure payment. Pay only when you\'re 100% satisfied.' },
            ].map((step, i) => (
              <div key={i} className="relative bg-white rounded-3xl p-8 border border-slate-200">
                <div className="text-5xl font-black text-slate-100 absolute top-4 right-4">0{i + 1}</div>
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-700 flex items-center justify-center text-white mb-5">{step.icon}</div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-slate-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { value: '2,847', label: 'Verified Pros', icon: <Users size={24} /> },
              { value: '142K+', label: 'Happy Customers', icon: <Award size={24} /> },
              { value: '96.4%', label: 'Completion Rate', icon: <CheckCircle2 size={24} /> },
              { value: '<60 min', label: 'Avg. Response', icon: <Clock size={24} /> },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-slate-400 flex justify-center mb-3">{stat.icon}</div>
                <div className="text-4xl lg:text-5xl font-black mb-2 bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">{stat.value}</div>
                <div className="text-sm text-slate-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portals CTA */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-black text-slate-900 mb-3">One platform. Five portals.</h2>
            <p className="text-slate-600">Explore each role-based interface built for the marketplace.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { id: 'customer' as const, label: 'Customer', icon: '👤', desc: 'Book & track services', color: 'from-blue-600 to-indigo-600' },
              { id: 'provider' as const, label: 'Provider', icon: '🔧', desc: 'Accept jobs & earn', color: 'from-emerald-600 to-teal-600' },
              { id: 'admin' as const, label: 'Admin', icon: '🛡️', desc: 'Operate marketplace', color: 'from-violet-600 to-purple-600' },
              { id: 'superadmin' as const, label: 'Super Admin', icon: '👑', desc: 'System control', color: 'from-amber-500 to-orange-600' },
              { id: 'support' as const, label: 'Support', icon: '🎧', desc: 'Help customers', color: 'from-cyan-500 to-blue-600' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => navigate(`/portal/${p.id}`)}
                className="group relative overflow-hidden rounded-2xl p-6 text-left border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${p.color} opacity-0 group-hover:opacity-100 transition-opacity`} />
                <div className="relative">
                  <div className="text-3xl mb-3">{p.icon}</div>
                  <div className="font-bold text-slate-900 group-hover:text-white transition-colors mb-1">{p.label}</div>
                  <div className="text-xs text-slate-500 group-hover:text-white/80 transition-colors">{p.desc}</div>
                  <ArrowRight size={16} className="mt-3 text-slate-400 group-hover:text-white transition-colors group-hover:translate-x-1" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 py-12">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center">
                  <span className="text-slate-900 font-black text-sm">W</span>
                </div>
                <span className="text-white font-black text-lg">WASTA</span>
              </div>
              <p className="text-sm">The UAE's most trusted home services marketplace.</p>
            </div>
            {[
              { title: 'Services', links: ['Cleaning', 'AC Repair', 'Plumbing', 'Electrical', 'Beauty'] },
              { title: 'Company', links: ['About', 'Careers', 'Blog', 'Press', 'Contact'] },
              { title: 'Support', links: ['Help Center', 'Safety', 'Terms', 'Privacy', 'Refunds'] },
            ].map((col) => (
              <div key={col.title}>
                <h4 className="text-white font-bold mb-3 text-sm">{col.title}</h4>
                <ul className="space-y-2 text-sm">
                  {col.links.map((l) => <li key={l}><a href="#" className="hover:text-white transition-colors">{l}</a></li>)}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-slate-800 pt-8 text-xs text-center">© 2025 WASTA Marketplace. Built with ❤️ in Dubai.</div>
        </div>
      </footer>
    </div>
  );
}
