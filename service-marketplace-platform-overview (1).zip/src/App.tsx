import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Topbar from './components/Topbar';
import Landing from './pages/Landing';
import Auth from './pages/Auth';
import CustomerPortal from './pages/portals/CustomerPortal';
import ProviderPortal from './pages/portals/ProviderPortal';
import AdminPortal from './pages/portals/AdminPortal';
import SuperAdminPortal from './pages/portals/SuperAdminPortal';
import SupportPortal from './pages/portals/SupportPortal';
import { Role } from './types';

const portalMap: Record<string, React.ComponentType> = {
  customer: CustomerPortal,
  provider: ProviderPortal,
  admin: AdminPortal,
  superadmin: SuperAdminPortal,
  support: SupportPortal,
};

function PortalRoute({ role }: { role: Role }) {
  const Page = portalMap[role];
  return <Page />;
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<><Topbar currentRole="landing" onChangeRole={() => {}} /><Landing /></>} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/portal/customer" element={<PortalRoute role="customer" />} />
        <Route path="/portal/provider" element={<PortalRoute role="provider" />} />
        <Route path="/portal/admin" element={<PortalRoute role="admin" />} />
        <Route path="/portal/superadmin" element={<PortalRoute role="superadmin" />} />
        <Route path="/portal/support" element={<PortalRoute role="support" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
