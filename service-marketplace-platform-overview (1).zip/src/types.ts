export type Role = 'landing' | 'customer' | 'provider' | 'admin' | 'superadmin' | 'support';

export interface RoleDef {
  id: Role;
  name: string;
  description: string;
  icon: string;
  color: string;
  gradient: string;
  personName: string;
  personTitle: string;
}

export const roles: Record<Exclude<Role, 'landing'>, RoleDef> = {
  customer: {
    id: 'customer',
    name: 'Customer',
    description: 'Book services, track providers, make payments',
    icon: '👤',
    color: 'blue',
    gradient: 'from-blue-600 to-indigo-600',
    personName: 'Sarah Al-Maktoum',
    personTitle: 'Homeowner · Dubai Marina',
  },
  provider: {
    id: 'provider',
    name: 'Provider',
    description: 'Accept jobs, manage schedule, track earnings',
    icon: '🔧',
    color: 'emerald',
    gradient: 'from-emerald-600 to-teal-600',
    personName: 'Khalid Ahmed',
    personTitle: 'Electrical Pro · Dubai',
  },
  admin: {
    id: 'admin',
    name: 'Admin Portal',
    description: 'Manage bookings, providers, and operations',
    icon: '🛡️',
    color: 'violet',
    gradient: 'from-violet-600 to-purple-600',
    personName: 'Omar Khalil',
    personTitle: 'Operations Manager',
  },
  superadmin: {
    id: 'superadmin',
    name: 'Super Admin',
    description: 'Control system, finance, and permissions',
    icon: '👑',
    color: 'amber',
    gradient: 'from-amber-500 to-orange-600',
    personName: 'Dr. Aisha Al-Nahyan',
    personTitle: 'CTO · WASTA',
  },
  support: {
    id: 'support',
    name: 'Support Center',
    description: 'Handle tickets, refunds, and escalations',
    icon: '🎧',
    color: 'cyan',
    gradient: 'from-cyan-500 to-blue-600',
    personName: 'Layla Rahman',
    personTitle: 'Senior Support Agent',
  },
};
